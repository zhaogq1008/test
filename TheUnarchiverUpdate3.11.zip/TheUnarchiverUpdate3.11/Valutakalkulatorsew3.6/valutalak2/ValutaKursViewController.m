//
//  ValutaKursViewController.m
//  Valutakalkulator
//
//  Created by Robin Grønvold on 7/20/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import "ValutaKursViewController.h"
#import "valutakalk2ViewController.h"
#import "ValutaTableCell.h"


@interface ValutaKursViewController ()

@end

@implementation ValutaKursViewController
@synthesize valutaList, unitList, sekRateString, flagList, currencyRates;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Kurser", @"Kurser");
        self.tabBarItem.image = [UIImage imageNamed:@"kurser"];
    }
    return self;
}
- (void) viewDidAppear:(BOOL)animated
{
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSUserDefaults *sekRate = [NSUserDefaults standardUserDefaults];
    sekRateString = [sekRate objectForKey:@"mySekRate"];
    NSLog(@"sekrate %@", sekRateString);
    
   // NSUserDefaults *sekRate = [NSUserDefaults standardUserDefaults];
   // [sekRate setObject:currencyRate forKey:@"mySekRate"];
   // [sekRate synchronize];
    
    NSUserDefaults *rateArrayClean = [NSUserDefaults standardUserDefaults];
    //NSArray *currencyRates = [[NSMutableArray alloc] init];
    currencyRates = [rateArrayClean objectForKey:@"myRateArray"];
    
    NSLog(@"The content of currencyRates is %@",currencyRates);
    [self.valutaTableView reloadData];
   
}

- (void)viewDidLoad
{
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSUserDefaults *sekRate = [NSUserDefaults standardUserDefaults];
    sekRateString = [sekRate objectForKey:@"mySekRate"];
    NSLog(@"mynokrate %@", sekRateString);
    
    NSUserDefaults *rateArrayClean = [NSUserDefaults standardUserDefaults];
    //NSArray *currencyRates = [[NSMutableArray alloc] init];
    currencyRates = [rateArrayClean objectForKey:@"myRateArray"];
    
    NSLog(@"The content of currencyRates is %@",currencyRates);


    
    valutaList=[[NSArray alloc] initWithObjects:@"SEK - Svenske kroner",@"USD - US Dollar",@"EUR - Euro",@"NOK - Norske kroner",@"DKK - Danske kroner",@"GBP - Britiske pund",@"CAD - Canadiske dollar",@"CHF - Sveitsiske franc", @"JPY - Japanske Yen",@"CNY - Kinesiske yuan renmminbi", @"THB - Thailanske bhat", @"AUD - Australske dollar", @"AED - United Arab Emirates Dirham", @"AFN - Afghanistan Afghani", @"ALL - Albania Lek", @"AMD - Armenia Dram", @"ANG - Netherlands Antilles Guilder", @"ARS - Argentina Peso",  @"AZN - Azerbaijan New Manat", @"BAM - Bosnia and Herzegovina Convertible Marka", @"BBD - Barbados Dollar", @"BDT - Bangladesh Taka", @"BGN - Bulgaria Lev",   @"BMD - Bermuda Dollar", @"BND - Brunei Darussalam Dollar", @"BOB - Bolivia Boliviano", @"BRL - Brazil Real", @"BSD - Bahamas Dollar", @"BWP - Botswana Pula", @"BYR - Belarus Ruble", @"BZD - Belize Dollar", @"CDF - Congo/Kinshasa Franc", @"CLP - Chile Peso", @"COP - Colombia Peso", @"CRC - Costa Rica Colon", @"CUC - Cuba Convertible Peso", @"CUP - Cuba Peso", @"CZK - Czech Republic Koruna", @"DOP - Dominican Republic Peso", @"DZD - Algeria Dinar", @"EGP - Egypt Pound", @"ERN - Eritrea Nakfa", @"ETB - Ethiopia Birr", @"GEL - Georgia Lari", @"GGP - Guernsey Pound", @"GHS - Ghana Cedi", @"GMD - Gambia Dalasi", @"GNF - Guinea Franc", @"GTQ - Guatemala Quetzal", @"GYD - Guyana Dollar", @"HKD - Hong Kong Dollar", @"HNL - Honduras Lempira", @"HRK - Croatia Kuna", @"HTG - Haiti Gourde", @"HUF - Hungary Forint", @"IDR - Indonesia Rupiah", @"ILS - Israel Shekel", @"INR - India Rupee", @"IQD - Iraq Dinar", @"IRR - Iran Rial", @"ISK - Iceland Krona", @"JEP - Jersey Pound", @"JMD - Jamaica Dollar", @"JOD - Jordan Dinar", @"KES - Kenya Shilling", @"KGS - Kyrgyzstan Som", @"KHR - Cambodia Riel", @"KMF - Comoros Franc", @"KPW - Korea (North) Won", @"KRW - Korea (South) Won", @"KWD - Kuwait Dinar", @"KYD - Cayman Islands Dollar", @"KZT - Kazakhstan Tenge", @"LAK - Laos Kip", @"LBP - Lebanon Pound", @"LKR - Sri Lanka Rupee", @"LRD - Liberia Dollar", @"LTL - Lithuania Litas", @"LVL - Latvia Lat", @"LYD - Libya Dinar", @"MAD - Morocco Dirham", @"MDL - Moldova Leu", @"MGA - Madagascar Ariary", @"MKD - Macedonia Denar", @"MMK - Myanmar (Burma) Kyat", @"MRO - Mauritania Ouguiya", @"MUR - Mauritius Rupee", @"MVR - Maldives (Maldive Islands) Rufiyaa", @"MWK - Malawi Kwacha", @"MXN - Mexico Peso", @"MYR - Malaysia Ringgit", @"MZN - Mozambique Metical", @"NAD - Namibia Dollar", @"NGN - Nigeria Naira", @"NIO - Nicaragua Cordoba", @"NPR - Nepal Rupee", @"NZD - New Zealand Dollar", @"OMR - Oman Rial", @"PAB - Panama Balboa", @"PEN - Peru Nuevo Sol", @"PGK - Papua New Guinea Kina", @"PHP - Philippines Peso", @"PKR - Pakistan Rupee", @"PLN - Poland Zloty", @"PYG - Paraguay Guarani", @"QAR - Qatar Riyal", @"RON - Romania New Leu", @"RSD - Serbia Dinar", @"RUB - Russia Ruble", @"RWF - Rwanda Franc", @"SAR - Saudi Arabia Riyal", @"SBD - Solomon Islands Dollar", @"SCR - Seychelles Rupee", @"SDG - Sudan Pound", @"SGD - Singapore Dollar",  @"SLL - Sierra Leone Leone", @"SOS - Somalia Shilling", @"SRD - Suriname Dollar", @"STD - São Tomé and Príncipe Dobra", @"SVC - El Salvador Colon", @"SYP - Syria Pound", @"SZL - Swaziland Lilangeni", @"TMT - Turkmenistan Manat", @"TND - Tunisia Dinar", @"TRY - Turkey Lira", @"TTD - Trinidad and Tobago Dollar",  @"TWD - Taiwan New Dollar", @"TZS - Tanzania Shilling", @"UAH - Ukraine Hryvna", @"UGX - Uganda Shilling", @"UYU - Uruguay Peso",  @"VEF - Venezuela Bolivar", @"VND - Viet Nam Dong", @"ZAR - South Africa Rand", @"ZMW - Zambia Kwacha", @"ZWD - Zimbabwe Dollar", nil];
    
    //图片保存在数组中
    flagList=[[NSArray alloc] initWithObjects:@"sek-sweden.png",@"usd.png",@"eur",@"nok-norway.png",@"dkk-denmark.png",@"gbp-uk.png",@"cad-canada.png",@"chf-sveits.png",	@"jpy-japan.png",	@"cny-china.png",@"thb-thailand.png",@"aud-australia.png",	@"aed-unitedarabemirates.png",	@"afn-afghan.png",	@"all-albania.png",	@"amd-armenia.png",	@"ang-nedantilguilder.png",	@"ars-argentina.png",		@"",	@"bam-bosniah.png",	@"bbd-barbados.png",	@"bdt-bangladesh.png",	@"bgn-bulgaria.png",	@"bmd-bermudadollar.png",	@"bnd-brunei.png",	@"bob-bolivia.png",	@"brl-brasil.png",	@"bsd-bahamas.png",	@"bwp-botwsana.png",	@"byr-hviterus.png",	@"bzd-belize.png",		@"cdf-congo.png",		@"clp-chile.png",	@"cop-columbia.png",	@"crc-costarica.png",	@"",	@"cup-cuba.png",	@"czk-czech.png",		@"dop-dominikanskepeso.png",	@"dzd-algeria.png",	@"egp-egypt.png",	@"ern-eritrea.png",	@"etb-ethiopia.png",	@"gel-georgia.png",	@"ggp-guernsy.png",	@"ghs-ghana.png",	@"gmd-gambia.png",	@"gnf-guinea.png",	@"gtq-guatemala.png",	@"gyd-guyaneisiskdollar.png",	@"hkd-hongkong.png",	@"hnl-honduras.png",	@"hrk-croatia.png",	@"htg-haiti.png",	@"huf-hungary.png",	@"idr-indonesia.png",	@"ils-israel.png",	@"inr-india.png",	@"iqd-iraq.png",	@"irr-iran.png",	@"isk-island.png",	@"jep-jersey.png",	@"jmd-jamaica.png",	@"jod-jordan.png",@"kes-kenya.png",	@"kgs-kirgist.png",	@"khr-kambodia.png",	@"kmf-comorus.png",	@"kpw-norkorea.png",	@"krw-sorkorea.png",	@"kwd-kuwait.png",	@"kyd-cayman.png",	@"kzt-kazakhstan.png",	@"lak-lao.png",	@"lbp-libanon.png",	@"lkr-srilanka.png",	@"lrd-liberia.png",	@"ltl-littauen.png",	@"lvl - lettiskelats.png",	@"",	@"mad-marokko.png",	@"mdl-moldova.png",	@"mga-madagask.png",	@"",	@"",	@"mro-mauritania.png",	@"mur-mauritania.png",	@"mvr-maldives.png",	@"mwk-malawi.png",	@"mxn-mexico.png",	@"myr-malaysia.png",	@"mzn-mozambique.png",	@"nad-namibia.png",	@"ngn-nigeria.png",	@"nio-nicaragua.png",		@"npr-nepal.png",	@"nzd-ewzealand.png",	@"omr-oman.png",	@"pab-panama.png",	@"",	@"pgk-papangchi.png",	@"php-phillipines.png",	@"pkr-pakistan.png",	@"pln-poland.png",	@"pyg-paraguay.png",	@"qar-quatar.png",	@"ron-romania.png",	@"rsd-serbia.png",	@"rub-russia.png",	@"rwf-rwanda.png",	@"sar-saudi.png",	@"sbd-salomon.png",	@"scr-seychellene.png",	@"sdg-sudan.png",		@"sgd-singapore.png",	@"sll-sierralone.png",	@"sos-somalia.png",	@"srd-suriname.png",	@"std-saotome.png",	@"svc-elsalv.png",	@"syp-syria.png",	@"szl-swaziland.png",		@"tjs-tajikistan.png",	@"tmt-turkmenistan.png",	@"tnd-tunisia.png",	@"try-turkey.png",	@"ttd-trinidad.png",	@"tvd-tuvalu.png",	@"twd-taiwan.png",	@"tzs-tanzania.png",	@"uah-ukraina.png",	@"ugx-uganda.png",		@"uyu-uruguay.png",	@"uzs-uzbek.png",	@"vef-venezuela.png",	@"vnd-vietnam.png",	@"wst-samoa.png",	@"",	@"yer-yemen.png",	@"zar-southafrica.png",	@"zmw-zambia.png",	@"zwd-zimbabww.png", nil];

    
    
    
    
    unitList=[[NSArray alloc] initWithObjects:@"100",@"1",@"1",@"100",@"100",@"1",@"1",@"100", @"100",@"1", @"100", @"1", @"1", @"100", @"100", @"AMD - Armenia Dram", @"ANG - Netherlands Antilles Guilder", @"ARS - Argentina Peso",  @"AZN - Azerbaijan New Manat", @"BAM - Bosnia and Herzegovina Convertible Marka", @"BBD - Barbados Dollar", @"BDT - Bangladesh Taka", @"BGN - Bulgaria Lev",   @"BMD - Bermuda Dollar", @"BND - Brunei Darussalam Dollar", @"BOB - Bolivia Boliviano", @"BRL - Brazil Real", @"BSD - Bahamas Dollar", @"BWP - Botswana Pula", @"BYR - Belarus Ruble", @"BZD - Belize Dollar", @"CDF - Congo/Kinshasa Franc", @"CLP - Chile Peso", @"COP - Colombia Peso", @"CRC - Costa Rica Colon", @"CUC - Cuba Convertible Peso", @"CUP - Cuba Peso", @"CZK - Czech Republic Koruna", @"DOP - Dominican Republic Peso", @"DZD - Algeria Dinar", @"EGP - Egypt Pound", @"ERN - Eritrea Nakfa", @"ETB - Ethiopia Birr", @"GEL - Georgia Lari", @"GGP - Guernsey Pound", @"GHS - Ghana Cedi", @"GMD - Gambia Dalasi", @"GNF - Guinea Franc", @"GTQ - Guatemala Quetzal", @"GYD - Guyana Dollar", @"HKD - Hong Kong Dollar", @"HNL - Honduras Lempira", @"HRK - Croatia Kuna", @"HTG - Haiti Gourde", @"HUF - Hungary Forint", @"IDR - Indonesia Rupiah", @"ILS - Israel Shekel", @"INR - India Rupee", @"IQD - Iraq Dinar", @"IRR - Iran Rial", @"ISK - Iceland Krona", @"JEP - Jersey Pound", @"JMD - Jamaica Dollar", @"JOD - Jordan Dinar", @"KES - Kenya Shilling", @"KGS - Kyrgyzstan Som", @"KHR - Cambodia Riel", @"KMF - Comoros Franc", @"KPW - Korea (North) Won", @"KRW - Korea (South) Won", @"KWD - Kuwait Dinar", @"KYD - Cayman Islands Dollar", @"KZT - Kazakhstan Tenge", @"LAK - Laos Kip", @"LBP - Lebanon Pound", @"LKR - Sri Lanka Rupee", @"LRD - Liberia Dollar", @"LTL - Lithuania Litas", @"LVL - Latvia Lat", @"LYD - Libya Dinar", @"MAD - Morocco Dirham", @"MDL - Moldova Leu", @"MGA - Madagascar Ariary", @"MKD - Macedonia Denar", @"MMK - Myanmar (Burma) Kyat", @"MRO - Mauritania Ouguiya", @"MUR - Mauritius Rupee", @"MVR - Maldives (Maldive Islands) Rufiyaa", @"MWK - Malawi Kwacha", @"MXN - Mexico Peso", @"MYR - Malaysia Ringgit", @"MZN - Mozambique Metical", @"NAD - Namibia Dollar", @"NGN - Nigeria Naira", @"NIO - Nicaragua Cordoba", @"NPR - Nepal Rupee", @"NZD - New Zealand Dollar", @"OMR - Oman Rial", @"PAB - Panama Balboa", @"PEN - Peru Nuevo Sol", @"PGK - Papua New Guinea Kina", @"PHP - Philippines Peso", @"PKR - Pakistan Rupee", @"PLN - Poland Zloty", @"PYG - Paraguay Guarani", @"QAR - Qatar Riyal", @"RON - Romania New Leu", @"RSD - Serbia Dinar", @"RUB - Russia Ruble", @"RWF - Rwanda Franc", @"SAR - Saudi Arabia Riyal", @"SBD - Solomon Islands Dollar", @"SCR - Seychelles Rupee", @"SDG - Sudan Pound", @"SGD - Singapore Dollar",  @"SLL - Sierra Leone Leone", @"SOS - Somalia Shilling", @"SRD - Suriname Dollar", @"STD - São Tomé and Príncipe Dobra", @"SVC - El Salvador Colon", @"SYP - Syria Pound", @"SZL - Swaziland Lilangeni", @"TMT - Turkmenistan Manat", @"TND - Tunisia Dinar", @"TRY - Turkey Lira", @"TTD - Trinidad and Tobago Dollar",  @"TWD - Taiwan New Dollar", @"TZS - Tanzania Shilling", @"UAH - Ukraine Hryvna", @"UGX - Uganda Shilling", @"UYU - Uruguay Peso",  @"VEF - Venezuela Bolivar", @"VND - Viet Nam Dong", @"ZAR - South Africa Rand", @"ZMW - Zambia Kwacha", @"ZWD - Zimbabwe Dollar", nil];
    
    

    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [valutaList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *currency = [valutaList objectAtIndex:indexPath.row];
    NSString *flag = [flagList objectAtIndex:indexPath.row];
    NSString *currencyShort = [currency substringToIndex:3];
    
    NSString *rate = [currencyRates objectAtIndex:indexPath.row];
    NSLog(@"rate in tableview is: %@", rate);
    double rateDouble = [rate doubleValue];
    double finalRate;
    double sekRateInt = [sekRateString doubleValue];
    NSLog (@"SEKRATE INT %f", sekRateInt);
    finalRate = (sekRateInt/rateDouble);
    
    static NSString *simpleTableIdentifier = @"ValutaTableCell";
    
    ValutaTableCell *cell = (ValutaTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ValutaTableCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }


        // Updating table view through table cell
        cell.rate.text = [NSString stringWithFormat:@"%.4f", finalRate];
        cell.valutaName.font = [UIFont systemFontOfSize:14];
        cell.rate.font = [UIFont systemFontOfSize:14];
        
        cell.valutaName.text = currency;
       
        cell.flagImage.image = [UIImage imageNamed: flag];
        cell.rate.text = [NSString stringWithFormat:@"%.4f", finalRate];
        [cell setNeedsDisplay];
        //
        if ([currencyShort isEqualToString:@"USD"]) {
           
            cell.rate.text = [NSString stringWithFormat:@"%.4f", sekRateInt];
        }
    return cell;
}

- (void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Cell.png"]];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
