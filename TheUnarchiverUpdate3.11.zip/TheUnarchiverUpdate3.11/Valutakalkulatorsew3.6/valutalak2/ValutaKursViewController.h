//
//  ValutaKursViewController.h
//  Valutakalkulator
//
//  Created by Robin Grønvold on 7/20/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ValutaKursViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *valutaTableView;
@property (strong, nonatomic) NSArray *valutaList;
@property (strong, nonatomic) NSArray *unitList;
@property (strong, nonatomic) NSArray *flagList;
@property (strong, nonatomic) NSString *sekRateString;
@property (strong, nonatomic) NSArray *currencyRates;

@end
