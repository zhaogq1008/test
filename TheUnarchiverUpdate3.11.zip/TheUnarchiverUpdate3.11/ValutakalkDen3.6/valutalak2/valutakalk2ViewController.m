//
//  valutakalk2ViewController.m
//  valutalak2
//
//  Created by Robin Grønvold on 1/17/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import "valutakalk2ViewController.h"
#import <QuartzCore/QuartzCore.h>


@interface valutakalk2ViewController ()

@end

@implementation valutakalk2ViewController
@synthesize valutainput;
@synthesize valutaTall, valutaOutput;
@synthesize belop;
@synthesize pickerView, valutaList, updateDateLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Kalkulator", @"Kalkulator");
        self.tabBarItem.image = [UIImage imageNamed:@"calculator"];
    }
    return self;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        [self update:nil];
    }
    if (buttonIndex == 1)
    {
        [self update:nil];
    }
}



- (void)viewDidLoad
{
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"valutakalk2ViewController_iPhone" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"valutakalk2ViewController_iPhone5" owner:self options:nil];
        }
        
    }else{
        [pickerView setFrame:CGRectMake(0, 0, 320, 216)];
    }
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSUserDefaults *dkkRate = [NSUserDefaults standardUserDefaults];
    NSString *dkkRateString = [dkkRate objectForKey:@"myDkkRate"];
    NSLog(@"mynokrate %@", dkkRateString);
    if ([dkkRateString length] == 0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Du har ikke opdateret citater", @"AlertView") message:NSLocalizedString(@"Tryk på OK for at downloade de nyeste priser.", @"AlertView") delegate:self cancelButtonTitle:NSLocalizedString(@"Ok", @"AlertView") otherButtonTitles:nil, nil];
        [alertView show];

    }
            
    valutaTall.layer.cornerRadius=7;
    UIToolbar* pickerViewToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 60)];
    pickerViewToolbar.barStyle = UIBarStyleBlackTranslucent;
    pickerViewToolbar.items = [NSArray arrayWithObjects:
                           
                           [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                           [[UIBarButtonItem alloc]initWithTitle:@"Legg til" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithPickerView)],
                           nil];
    [pickerViewToolbar sizeToFit];

        

    
    
    valutaInput.inputAccessoryView = pickerViewToolbar;
    valutaOutput.inputAccessoryView = pickerViewToolbar;
    belop.inputAccessoryView = pickerViewToolbar;
    NSUserDefaults *update = [NSUserDefaults standardUserDefaults];
    NSString *updateDateString = [update objectForKey:@"myLastUpdate"];
    updateDateLabel.text = updateDateString;
    
    belop.keyboardType = UIKeyboardTypePhonePad;
    //[valutainput setDelegate:self];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNetworkChange:) name:kReachabilityChangedNotification object:nil];
    

    valutaList=[[NSArray alloc] initWithObjects:@"DKK - Danske kroner",@"USD - US Dollar",@"EUR - Euro",@"NOK - Norske kroner",@"DKK - Danske kroner",@"SEK - Svenske kroner",@"CAD - Canadiske dollar",@"CHF - Sveitsiske franc", @"JPY - Japanske Yen",@"CNY - Kinesiske yuan renmminbi", @"THB - Thailanske bhat", @"AUD - Australske dollar", @"AED - United Arab Emirates Dirham", @"AFN - Afghanistan Afghani", @"ALL - Albania Lek", @"AMD - Armenia Dram", @"ANG - Netherlands Antilles Guilder", @"ARS - Argentina Peso",  @"AZN - Azerbaijan New Manat", @"BAM - Bosnia and Herzegovina Convertible Marka", @"BBD - Barbados Dollar", @"BDT - Bangladesh Taka", @"BGN - Bulgaria Lev",   @"BMD - Bermuda Dollar", @"BND - Brunei Darussalam Dollar", @"BOB - Bolivia Boliviano", @"BRL - Brazil Real", @"BSD - Bahamas Dollar", @"BWP - Botswana Pula", @"BYR - Belarus Ruble", @"BZD - Belize Dollar", @"CDF - Congo/Kinshasa Franc", @"CLP - Chile Peso", @"COP - Colombia Peso", @"CRC - Costa Rica Colon", @"CUC - Cuba Convertible Peso", @"CUP - Cuba Peso", @"CZK - Czech Republic Koruna", @"DOP - Dominican Republic Peso", @"DZD - Algeria Dinar", @"EGP - Egypt Pound", @"ERN - Eritrea Nakfa", @"ETB - Ethiopia Birr", @"GEL - Georgia Lari", @"GGP - Guernsey Pound", @"GHS - Ghana Cedi", @"GMD - Gambia Dalasi", @"GNF - Guinea Franc", @"GTQ - Guatemala Quetzal", @"GYD - Guyana Dollar", @"HKD - Hong Kong Dollar", @"HNL - Honduras Lempira", @"HRK - Croatia Kuna", @"HTG - Haiti Gourde", @"HUF - Hungary Forint", @"IDR - Indonesia Rupiah", @"ILS - Israel Shekel", @"INR - India Rupee", @"IQD - Iraq Dinar", @"IRR - Iran Rial", @"ISK - Iceland Krona", @"JEP - Jersey Pound", @"JMD - Jamaica Dollar", @"JOD - Jordan Dinar", @"KES - Kenya Shilling", @"KGS - Kyrgyzstan Som", @"KHR - Cambodia Riel", @"KMF - Comoros Franc", @"KPW - Korea (North) Won", @"KRW - Korea (South) Won", @"KWD - Kuwait Dinar", @"KYD - Cayman Islands Dollar", @"KZT - Kazakhstan Tenge", @"LAK - Laos Kip", @"LBP - Lebanon Pound", @"LKR - Sri Lanka Rupee", @"LRD - Liberia Dollar", @"LTL - Lithuania Litas", @"LVL - Latvia Lat", @"LYD - Libya Dinar", @"MAD - Morocco Dirham", @"MDL - Moldova Leu", @"MGA - Madagascar Ariary", @"MKD - Macedonia Denar", @"MMK - Myanmar (Burma) Kyat", @"MRO - Mauritania Ouguiya", @"MUR - Mauritius Rupee", @"MVR - Maldives (Maldive Islands) Rufiyaa", @"MWK - Malawi Kwacha", @"MXN - Mexico Peso", @"MYR - Malaysia Ringgit", @"MZN - Mozambique Metical", @"NAD - Namibia Dollar", @"NGN - Nigeria Naira", @"NIO - Nicaragua Cordoba", @"NPR - Nepal Rupee", @"NZD - New Zealand Dollar", @"OMR - Oman Rial", @"PAB - Panama Balboa", @"PEN - Peru Nuevo Sol", @"PGK - Papua New Guinea Kina", @"PHP - Philippines Peso", @"PKR - Pakistan Rupee", @"PLN - Poland Zloty", @"PYG - Paraguay Guarani", @"QAR - Qatar Riyal", @"RON - Romania New Leu", @"RSD - Serbia Dinar", @"RUB - Russia Ruble", @"RWF - Rwanda Franc", @"SAR - Saudi Arabia Riyal", @"SBD - Solomon Islands Dollar", @"SCR - Seychelles Rupee", @"SDG - Sudan Pound", @"SGD - Singapore Dollar",  @"SLL - Sierra Leone Leone", @"SOS - Somalia Shilling", @"SRD - Suriname Dollar", @"STD - São Tomé and Príncipe Dobra", @"SVC - El Salvador Colon", @"SYP - Syria Pound", @"SZL - Swaziland Lilangeni", @"TMT - Turkmenistan Manat", @"TND - Tunisia Dinar", @"TRY - Turkey Lira", @"TTD - Trinidad and Tobago Dollar",  @"TWD - Taiwan New Dollar", @"TZS - Tanzania Shilling", @"UAH - Ukraine Hryvna", @"UGX - Uganda Shilling", @"UYU - Uruguay Peso",  @"VEF - Venezuela Bolivar", @"VND - Viet Nam Dong", @"ZAR - South Africa Rand", @"ZMW - Zambia Kwacha", @"ZWD - Zimbabwe Dollar", nil];
        belop.text =@"1";
    valutaInput.text=@"DKK";
    valutaOutput.text=@"DKK";
    
//    UIPickerView *pv = [[UIPickerView alloc] initWithFrame: CGRectMake(0,0,320,216)];
//    pv.showsSelectionIndicator = YES;
//    pv.userInteractionEnabled = YES;
//    [pv setDelegate:self];
//    [pv setDataSource:self];
//
//    valutaInput.inputView = pv;
    
    valutaInput.inputView = pickerView;
    valutaOutput.inputView = pickerView;
    pickerView.userInteractionEnabled = YES;
    pickerView.showsSelectionIndicator = TRUE;
    [pickerView setHidden:YES];
    
    [super viewDidLoad];
}

-(void)cancelPickerView{
    
    if ([valutaInput isFirstResponder]) {
        valutaInput.text = @"DKK";
        [valutaInput resignFirstResponder];
    }
    if ([valutaOutput isFirstResponder]) {
        valutaOutput.text = @"DKK";
        [valutaOutput resignFirstResponder];
    }
    
}

-(void)doneWithPickerView{
    if ([valutaInput isFirstResponder]) {
        [valutaInput resignFirstResponder];
        [self myAction];
        [self kalkuler:nil];
    }
    if ([valutaOutput isFirstResponder]) {
        [valutaOutput resignFirstResponder];
        [self myAction2];
        [self kalkuler:nil];
    }
    if ([belop isFirstResponder]) {
        [belop resignFirstResponder];
        //[self myAction2];
        [self kalkuler:nil];
    }
}

- (void)myAction
{
    
    NSInteger row = [pickerView selectedRowInComponent:0];
    NSString *text2 = [valutaList objectAtIndex:row];
    valutaInput.text=[text2 substringToIndex:3];
}
- (void)myAction2
{
    
    NSInteger row = [pickerView selectedRowInComponent:0];
    NSString *text3 = [valutaList objectAtIndex:row];
    valutaOutput.text=[text3 substringToIndex:3];
}


//pickViewDatesource 的代理方法
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {

    
    NSLog(@"Count = %d", [valutaList count]);
    return [valutaList count];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1; // or 2 or more
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    NSLog(@"%@", [valutaList objectAtIndex:row]);
    return [valutaList objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if([valutaOutput isFirstResponder]==TRUE)
    {
        NSString *text1;
        text1 = [valutaList objectAtIndex:row];
        valutaOutput.text= [text1 substringToIndex:3];
        //[self.view endEditing:TRUE];
        return;
    }
    if([valutaInput isFirstResponder]==TRUE)
    {
        NSString *text1;
        text1 = [valutaList objectAtIndex:row];
        valutaInput.text=[text1 substringToIndex:3];
       // [self.view endEditing:TRUE];
        return;
    }
    
}


-(IBAction)textFieldReturn:(id)sender
{
    [sender resignFirstResponder];
}

-(IBAction)textFieldEnter:(id)sender
{
    [pickerView setHidden:NO];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [pickerView setHidden:NO];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    //[belop resignFirstResponder];
    [pickerView setHidden:YES];
    
}

//This method connects to the Yahoo Finance website and downloads last rates
//更新时间的和请求网络数据的方法
- (IBAction)update:(id)sender;
{
    //[self checkForInternetConnection];
    Reachability* internetReach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [internetReach currentReachabilityStatus];
    //网络连接不了
    if (netStatus == NotReachable)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Du har ikke netværk!", @"AlertView") message:NSLocalizedString(@"Du skal være tilsluttet internettet for at hente citater", @"AlertView") delegate:nil cancelButtonTitle:NSLocalizedString(@"Ok", @"AlertView") otherButtonTitles:nil, nil];
        
        [alertView show];
    }
    
    //Get data and perform calculation
    //连接网络
    if (netStatus != NotReachable) {
        //Get CSV file
                    
        NSString *quoteAdress = [NSString stringWithFormat:@"http://finance.yahoo.com/d/quotes.csv?e=.csv&f=sl1d1t1&s=USDDKK=X,USDUSD=X,USDEUR=X,USDNOK=X ,USDSEK=X  ,USDGBP=X ,USDCAD=X ,USDCHF=X ,USDJPY=X ,USDCNY=X ,USDTHB=X ,USDAUD=X,USDAED=X,USDAFN=X,USDALL=X,USDAMD=X ,	USDANG=X,USDARS=X,USDAZN=X,USDBAM=X,USDBBD=X,USDBDT=X ,	USDBGN=X ,	USDBMD=X ,	USDBND=X ,	USDBOB=X ,	USDBRL=X ,	USDBSD=X,	USDBWP=X ,	USDBYR=X ,	USDBZD=X ,		USDCDF=X ,		USDCLP=X ,		USDCOP=X ,	USDCRC=X ,	USDCUC=X ,	USDCUP=X,	USDCZK=X,		USDDOP=X ,	USDDZD=X ,	USDEGP=X ,	USDERN=X ,	USDETB=X ,		USDGEL=X ,	USDGGP=X ,	USDGHS=X ,	USDGMD=X ,	USDGNF=X ,	USDGTQ=X ,	USDGYD=X ,	USDHKD=X ,	USDHNL=X ,	USDHRK=X ,	USDHTG=X ,	USDHUF=X ,	USDIDR=X ,	USDILS=X,	USDINR=X ,	USDIQD=X ,	USDIRR=X ,	USDISK=X ,	USDJEP=X ,	USDJMD=X ,	USDJOD=X ,		USDKES=X ,	USDKGS=X ,	USDKHR=X ,	USDKMF=X ,	USDKPW=X ,	USDKRW=X ,	USDKWD=X ,	USDKYD=X ,	USDKZT=X ,	USDLAK=X ,	USDLBP=X ,	USDLKR=X ,	USDLRD=X,	USDLTL=X ,	USDLVL=X ,	USDLYD=X ,	USDMAD=X ,	USDMDL=X ,	USDMGA=X ,	USDMKD=X ,	USDMMK=X ,	USDMRO=X ,	USDMUR=X ,	USDMVR=X ,	USDMWK=X ,	USDMXN=X ,	USDMYR=X ,	USDMZN=X ,	USDNAD=X ,	USDNGN=X ,	USDNIO=X ,		USDNPR=X ,	USDNZD=X ,	USDOMR=X ,	USDPAB=X ,	USDPEN=X ,	USDPGK=X ,	USDPHP=X ,	USDPKR=X ,	USDPLN=X ,	USDPYG=X ,	USDQAR=X ,	USDRON=X ,	USDRSD=X ,	USDRUB=X ,	USDRWF=X ,	USDSAR=X ,	USDSBD=X ,	USDSCR=X ,	USDSDG=X ,		USDSGD=X ,	USDSLL=X ,	USDSOS=X ,USDSRD=X ,	USDSTD=X ,	USDSVC=X ,	USDSYP=X ,	USDSZL=X ,	USDTMT=X ,	USDTND=X ,	USDTRY=X ,	USDTTD=X ,	USDTWD=X ,	USDTZS=X ,	USDUAH=X ,	USDUGX=X ,		USDUYU=X ,	USDVEF=X ,	 USDVND=X,USDZAR=X ,USDZMW=X ,USDZWD=X ,	"];
        
        
        NSURL *theURL = [[NSURL alloc] initWithString: [quoteAdress stringByAddingPercentEscapesUsingEncoding: NSASCIIStringEncoding]];
        NSURLRequest *theRequest = [[NSURLRequest alloc] initWithURL:theURL]; 
        NSURLResponse *response = nil;
        NSError *error = nil;
        NSData *data = [NSURLConnection sendSynchronousRequest:theRequest returningResponse:&response error:&error];
        NSMutableString *contentString = [[NSMutableString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        //NSLog(@"Contentstring%@", contentString);
        NSArray *arrayData = [contentString componentsSeparatedByString:@"\n"];
        
        //arrayData 保存的数据是每一组的数据
        //NSLog(@"The content of arrayData is %@",arrayData);
        NSString *dateString = [NSDateFormatter localizedStringFromDate:[NSDate date]
                                                              dateStyle:NSDateFormatterShortStyle
                                                              timeStyle:NSDateFormatterShortStyle];
        //NSLog(@"%@",dateString);
       
        NSString *updateAlert = [NSString stringWithFormat:@"uppdaterad: %@", dateString];
        //SAVE GLOBAL VARIABLE
        NSUserDefaults *updateDate = [NSUserDefaults standardUserDefaults];
        //最后更新时间
        [updateDate setObject:updateAlert forKey:@"myLastUpdate"];
        [updateDate synchronize];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Citation opdateret"
                                                        message:updateAlert
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
        updateDateLabel.text = updateAlert;
        //Massage the csv file
        NSString *currencyDataFromYahoo;
        NSString *currencyName;
        NSString *currencyRate;
        NSMutableArray *currencyArrayFromYahoo;
        currencyArrayFromYahoo = [[NSMutableArray alloc] init];
        NSMutableArray *rateArrayFromYahoo;
        rateArrayFromYahoo = [[NSMutableArray alloc] init];
        int count = [arrayData count]-1;
        //For loop to run through all the csv file.First for loop runs through each item and put in new array
        for(int i=0; i<count; i++){
            currencyDataFromYahoo = [arrayData objectAtIndex:i];
            NSArray* stringComponents = [currencyDataFromYahoo componentsSeparatedByString:@","];
           // NSLog(@"The content of stringcomponents is %@",stringComponents);
           // NSLog(@"object 0 in stringcomponent %@", [stringComponents objectAtIndex:0]);
            
            //For loop that goes through array with each currency (name, rate,date and time)
            for(int i=0; i<1; i++){
                currencyName = [stringComponents objectAtIndex:0];
                currencyName=[currencyName substringWithRange:NSMakeRange(1, [currencyName length]-4)];
              //  NSLog(@"CurrencyName %@", currencyName);  //USDSEK
                currencyRate = [stringComponents objectAtIndex:1];
                NSLog(@"CurrencyRate %@", currencyRate);
                [currencyArrayFromYahoo addObject:currencyName];
                
                [rateArrayFromYahoo addObject:currencyRate];
                NSLog(@"The content of currencyRateFromYahoo is %@",rateArrayFromYahoo);
                if ([currencyName isEqualToString:@"USDDKK"]) {
                    //SAVE GLOBAL VARIABLE
                    NSUserDefaults *sekRate = [NSUserDefaults standardUserDefaults];
                    [sekRate setObject:currencyRate forKey:@"myDkkRate"];
                    [sekRate synchronize];
                    
                    NSLog(@"mydkkrate %@", currencyName);

                }
        
            }
        }
        //NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSUserDefaults *currencyArrayClean = [NSUserDefaults standardUserDefaults];
        [currencyArrayClean setObject:currencyArrayFromYahoo forKey:@"myCurrencyArray"];
         [currencyArrayClean synchronize];
        NSArray *currencyNamesTest= [currencyArrayClean objectForKey:@"myCurrencyArray"];
        NSLog(@"The content of currencytest is %@",currencyNamesTest);
        
               
       // 
        //SAVE GLOBAL VARIABLE
        NSUserDefaults *rateArrayClean = [NSUserDefaults standardUserDefaults];
        [rateArrayClean setObject:rateArrayFromYahoo forKey:@"myRateArray"];
        [rateArrayClean synchronize];
        NSLog(@"arrays are synched");
        
        NSArray *test = [rateArrayClean objectForKey:@"myRateArray"];
        NSLog(@"The content of test is %@",test);
        

        
    }
    
}


//计算货币兑换的方法
- (IBAction) kalkuler:(id) sender;
{
    [belop resignFirstResponder];
    [pickerView setHidden:YES];
    [self.view endEditing:TRUE];
    //Declare input valuta strings
    NSString *valuta;
    NSString *valuta2;
    NSString *valutaUppercase;
    NSString *valuta2Uppercase;
    NSString *belopinn;
    belopinn = belop.text;
    double belopinnint = [belopinn doubleValue];
        
    //Set input from textfield to variables
    valutaUppercase = valutaInput.text;
    valuta2Uppercase = valutaOutput.text;
    valuta =  [valutaUppercase uppercaseString];
    valuta2 =  [valuta2Uppercase uppercaseString];
    NSString *combined = [NSString stringWithFormat:@"%@%@", valuta, valuta2];
    NSLog(@"Combined Valuta String is %@", combined);
    NSString *combinedShort = [combined substringToIndex:3];
    NSLog(@"combined short %@", combinedShort);
    NSString *nonUSString1 = [NSString stringWithFormat:@"USD%@", valuta];
    NSLog(@"nonUSString1%@", nonUSString1);
    NSString *nonUSString2 = [NSString stringWithFormat:@"USD%@", valuta2];
     NSLog(@"nonUSString2%@", nonUSString2);
        //Get saved arrays with currencies
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
   // NSArray *currencyNames = [[NSMutableArray alloc] init];
     NSArray *currencyNames = [defaults objectForKey:@"myCurrencyArray"];
    NSLog(@"The content of currencyName is %@",currencyNames);
  //  NSArray *currencyRates
  //  NSArray *currencyRates = [[NSMutableArray alloc] init];
    NSArray * currencyRates = [defaults objectForKey:@"myRateArray"];
    NSLog(@"The content of currencyRates is %@",currencyRates);
    NSString *rate;
    NSString *nonUSrate1;
    NSString *nonUSrate2;
    
    
    int count = [currencyNames count]-1;
    
    //  if input is USD
    if ([combinedShort isEqual: @"USD"] )
    {
        for(int i=0; i<count; i++){
            NSString *currencyNameString = [currencyNames objectAtIndex:i];
            //NSLog(@"CurrencyNameString %@", currencyNameString);
            if ([currencyNameString isEqualToString: combined]) {
                rate = [currencyRates objectAtIndex:i];
                //NSLog(@"rate %@", rate);
                double valutaint = [rate doubleValue];
                if (valutaint * belopinnint < 100) {
                    valutaTall.text = [NSString stringWithFormat:@"%.04f", valutaint * belopinnint];
                } else {
                    valutaTall.text = [NSString stringWithFormat:@"%.02f", valutaint * belopinnint];
                }
            }
        }
        if ([valuta2 isEqualToString:@"USD"]) {
            //NSLog(@"second currency is %@", valuta2);
            //NSLog(@"valuta is %@", valuta);
            valutaTall.text = [NSString stringWithFormat:@"%.02f", 1 * belopinnint];
        }
        
    }
    
    //if input is not USD
    else{
        for(int i=0; i<count; i++){
            NSString *currencyNameString1 = [currencyNames objectAtIndex:i];
            //NSString *currencyNameString2 = [currencyNames objectAtIndex:i];
            //NSLog(@"CurrencyNameString1 %@", currencyNameString1);
            if ([currencyNameString1 isEqualToString: nonUSString1]) {
                nonUSrate1 = [currencyRates objectAtIndex:i];
                NSLog(@"nonusrate %@", nonUSrate1);
            }
        }
        for(int i=0; i<count; i++){
            NSString *currencyNameString1 = [currencyNames objectAtIndex:i];
            //NSString *currencyNameString2 = [currencyNames objectAtIndex:i];
            //NSLog(@"CurrencyNameString1 %@", currencyNameString1);
            if ([currencyNameString1 isEqualToString: nonUSString2]) {
                nonUSrate2 = [currencyRates objectAtIndex:i];
              //  NSLog(@"nonusrate2 %@", nonUSrate2);
            }
        }
        
        double nonUSrateDouble1;
        double nonUSrateDouble2;
        float rateResult = 0.0;
        NSString *nonCombined = [NSString stringWithFormat:nonUSString1, nonUSString2];
        NSLog(@"noncombined %@", nonCombined);
        nonUSrateDouble1 = [[NSDecimalNumber decimalNumberWithString:nonUSrate1] doubleValue];
        NSLog(@"nonusratedouble %f", nonUSrateDouble1);
        nonUSrateDouble2 = [[NSDecimalNumber decimalNumberWithString:nonUSrate2] doubleValue];
        NSLog(@"nonusratedouble %f", nonUSrateDouble1);
        NSLog(@"nonusratedouble2 %f", nonUSrateDouble2);
        if ([valuta2 isEqualToString:@"USD"]) {
           // NSLog(@"second currency is %@", valuta2);
           // NSLog(@"valuta is %@", valuta);
            if ([valuta isEqualToString:@"USD"]){
                valutaTall.text = [NSString stringWithFormat:@"%.02f", 1 * belopinnint];
             //   NSLog(@"valuta is %@", valuta);
            }
            else {
                NSLog(@"else");
                    rateResult = (1/nonUSrateDouble1);
                    NSLog(@"nonUSRateDouble2 %f", nonUSrateDouble1);
                
                    if (rateResult * belopinnint < 100) {
                        valutaTall.text = [NSString stringWithFormat:@"%.04f", rateResult * belopinnint];
                    }
                    else {
                        valutaTall.text = [NSString stringWithFormat:@"%.02f", rateResult * belopinnint];
                    }

            }
        }
        else {
            
            rateResult = (nonUSrateDouble2 / nonUSrateDouble1);
            NSLog (@"rateresult%f", rateResult);
        
            if (rateResult * belopinnint < 100) {
                valutaTall.text = [NSString stringWithFormat:@"%.04f", rateResult * belopinnint];
            }
            else {
                valutaTall.text = [NSString stringWithFormat:@"%.02f", rateResult * belopinnint];
            }
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)reset:(id)sender {
    [belop resignFirstResponder];
    belop.text =@"1";
    valutaInput.text=@"DKK";
    valutaOutput.text=@"DKK";
    valutaTall.text = @"";
}

@end
