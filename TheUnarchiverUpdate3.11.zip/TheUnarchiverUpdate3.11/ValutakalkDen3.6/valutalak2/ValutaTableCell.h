//
//  SimpleTableCell.h
//  
//
//  Created by Robin Grønvold on 3/28/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ValutaTableCell : UITableViewCell{
   // BOOL *checkboxSelected;
    IBOutlet UIView *view1;
    
}
@property (weak, nonatomic) IBOutlet UILabel *valutaName;

@property (weak, nonatomic) IBOutlet UILabel *rate;

@property (weak, nonatomic) IBOutlet UIImageView *flagImage;


@end
