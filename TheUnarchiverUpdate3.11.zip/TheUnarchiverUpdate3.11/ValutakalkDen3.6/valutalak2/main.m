//
//  main.m
//  valutalak2
//
//  Created by Robin Grønvold on 1/17/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "valutakalk2AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([valutakalk2AppDelegate class]));
    }
}
