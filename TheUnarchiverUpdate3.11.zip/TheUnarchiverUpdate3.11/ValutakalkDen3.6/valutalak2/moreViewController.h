//
//  moreViewController.h
//  Valutakalkulator
//
//  Created by Robin Grønvold on 7/24/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface moreViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) NSArray *appList;
@property (strong, nonatomic) NSArray *descriptionList;
@property (strong, nonatomic) NSArray *imageList;
@property (strong, nonatomic) NSArray *urlList;
@property (weak, nonatomic) IBOutlet UITableView *moreTableView;

@end
