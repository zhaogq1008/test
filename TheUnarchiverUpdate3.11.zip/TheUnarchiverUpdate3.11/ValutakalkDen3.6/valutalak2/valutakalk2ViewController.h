//
//  valutakalk2ViewController.h
//  valutalak2
//
//  Created by Robin Grønvold on 1/17/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Appirater.h"
#import "Reachability.h"

@interface valutakalk2ViewController : UIViewController <UIPickerViewDataSource,UIPickerViewDelegate, UIAlertViewDelegate, UITextFieldDelegate>
{
    
    IBOutlet UITextField *valutaInput;
    IBOutlet UILabel *valutaTall;
    IBOutlet UITextField *valutaOutput;
    IBOutlet UITextField *belop;

}


@property(nonatomic, retain) IBOutlet UITextField *valutainput;
@property (nonatomic, retain) IBOutlet UITextField *valutaOutput;
@property (nonatomic, retain) IBOutlet UILabel *valutaTall;
@property (nonatomic, retain) IBOutlet UITextField *belop;
@property (nonatomic, retain) IBOutlet UIPickerView *pickerView;
@property (strong, nonatomic) NSArray *valutaList;
@property (weak, nonatomic) IBOutlet UILabel *updateDateLabel;

- (IBAction)textFieldReturn:(id)sender;
- (IBAction)textFieldEnter:(id)sender;
- (IBAction) kalkuler:(id) sender;
- (IBAction)reset:(id)sender;
- (IBAction)update:(id)sender;

//- (void)checkForWIFIConnection;

@end
