//
//  valutakalk2AppDelegate.h
//  valutalak2
//
//  Created by Robin Grønvold on 1/17/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Appirater.h"

@class valutakalk2ViewController;

@interface valutakalk2AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

//@property (strong, nonatomic) valutakalk2ViewController *viewController;

@property (strong, nonatomic) UITabBarController *tabBarController;

@end
