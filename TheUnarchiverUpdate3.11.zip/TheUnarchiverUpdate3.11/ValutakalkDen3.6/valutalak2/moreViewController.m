//
//  moreViewController.m
//  Valutakalkulator
//
//  Created by Robin Grønvold on 7/24/13.
//  Copyright (c) 2013 Appsonite. All rights reserved.
//

#import "moreViewController.h"
#import "moreTableCell.h"

@interface moreViewController ()

@end

@implementation moreViewController
@synthesize appList, descriptionList, imageList, urlList;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = NSLocalizedString(@"Flere apper", @"Flere apper");
        self.tabBarItem.image = [UIImage imageNamed:@"more_n.png"];
    }
    return self;
}

- (void)viewDidLoad
{
    appList=[[NSArray alloc] initWithObjects:@"Kaloriteller", @"Job Interview App",@"Egenmelding", @"Jobb Intervju - Norsk",@"The Flying Game",nil];
    descriptionList=[[NSArray alloc] initWithObjects:@"Gå ner i vikt med denna lilla hjälpreda. Kaloriräknare av norska livsmedel och kalori / träningsdagbok. Räkna dina kalorier, och spåra vad du äter.",@"Över 250 frågor och svar (på engelska). Denna applikation har video frågor, svar och råd. Du kan spela in dina egna svar på videoklipp.",@"Skriv ett själv certifikat på iPhone. Skriv och skicka e-post till din chef när du är sjuk. Håll koll på dina egna meddelanden.",@"50 norska frågor och svar som man kan förvänta sig på anställningsintervju. ",@"Ladda ner denna gratis online flygande spel där du kan spela in din egen röst och skapa ljudeffekter.",nil];
    imageList=[[NSArray alloc] initWithObjects:@"KaloritellerIcon-72.png",@"JobbInterviewIcon-72.png",@"EgenmeldingIcon-72.png",@"JobbIntervjuIcon-72.png",@"flyinggameIcon-72.png",nil];
    urlList =[[NSArray alloc] initWithObjects:@"itms-apps://itunes.apple.com/no/app/kaloriteller/id682733761?mt=8&uo=4",@"itms-apps://itunes.apple.com/no/app/job-interview-app/id475889617?mt=8&uo=4", @"itms-apps://itunes.apple.com/no/app/egenmelding/id660316686?mt=8&uo=4", @"itms-apps://itunes.apple.com/no/app/jobb-intervju/id635707765?mt=8&uo=4",@"http://www.baidu.com/",nil];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [appList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"ValutaTableCell";
    
    moreTableCell *cell = (moreTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    // NSString *deviceType = [UIDevice currentDevice].model;
    

    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"moreTableCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }

    // Updating table view through table cell
    cell.appName.font = [UIFont systemFontOfSize:14];
    cell.appDescription.font = [UIFont systemFontOfSize:10];
    NSString *appName = [appList objectAtIndex:indexPath.row];
    cell.appName.text = appName;
    NSString *appIcon = [imageList objectAtIndex:indexPath.row];
    cell.appImage.image = [UIImage imageNamed: appIcon];

    NSString *description = [descriptionList objectAtIndex:indexPath.row];
    cell.appDescription.text = description;
    return cell;
    
    /*
    if([deviceType isEqualToString:@"iPad"])
    {
        
        if (cell == nil) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"moreTableCell_iPad" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        // Updating table view through table cell
        cell.appName.font = [UIFont systemFontOfSize:20];
        cell.appDescription.font = [UIFont systemFontOfSize:18];
        NSString *appName = [appList objectAtIndex:indexPath.row];
        cell.appName.text = appName;
        NSString *appIcon = [imageList objectAtIndex:indexPath.row];
        cell.appImage.image = [UIImage imageNamed: appIcon];
        
        NSString *description = [descriptionList objectAtIndex:indexPath.row];
        cell.appDescription.text = description;
        return cell;
     
    }
     */
}

- (void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Cell.png"]];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 80;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"第%d行",indexPath.row);
    int i = [urlList count];
    NSLog(@"urlList 的个数是%d",i);
    
    NSString *url = [urlList objectAtIndex:indexPath.row];
    //NSString *completeUrl =[NSString stringWithFormat:@"itms-apps:%@", url];
    NSLog(@"myUrl %@", url);
   
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
