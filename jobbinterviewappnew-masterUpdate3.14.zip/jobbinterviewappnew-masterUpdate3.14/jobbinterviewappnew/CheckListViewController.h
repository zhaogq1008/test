//
//  CheckListViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckListAnswer.h"
#import <iAd/iAd.h>

@interface CheckListViewController : UIViewController <ADBannerViewDelegate>
{
    ADBannerView *addView;
}
@property (nonatomic, retain) IBOutlet ADBannerView *addView;

-(IBAction) actionAboutCompany:(id)sender;
-(IBAction) actionAboutJob:(id)sender;
-(IBAction) actionKnowMyself:(id)sender;
-(IBAction) actionPPractise:(id)sender;
-(IBAction) actionInterview:(id)sender;
-(IBAction) actionAtInterview:(id)sender;


@end
