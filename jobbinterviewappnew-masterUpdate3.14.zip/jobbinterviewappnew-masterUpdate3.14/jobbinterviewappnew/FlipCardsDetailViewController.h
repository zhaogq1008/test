//
//  FlipCardsDetailViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FlipCardView.h"

@interface FlipCardsDetailViewController : UIViewController<UIScrollViewDelegate>
{
    IBOutlet UIScrollView   *scrollFlipCard;
    IBOutlet UILabel        *lblPage;
    
    CGSize                  scrollSize;
    NSMutableArray          *arrAnswer;
    NSMutableArray          *arrQuestion;
    int                     numsOfQuestion;
    int                     numsOfFreeCards;
}
@property (retain , nonatomic) NSString *refData;

- (void) resetLable;

- (IBAction) actionPrev;
- (IBAction) actionNext;



@end
