//
//  jobbinterviewIAPHelper.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/30/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "IAPHelper.h"

@interface jobbinterviewIAPHelper : IAPHelper

@end
