//
//  FlipCardView.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlipCardView : UIView
{
    UITextView *frontCard;
    UITextView *backCard;
    BOOL isFlipped;
}
@property (assign, nonatomic) int point_index;
- (id)initWithFrame:(CGRect)frame Question:(NSString*)question Answer:(NSString*) answer;
@end
