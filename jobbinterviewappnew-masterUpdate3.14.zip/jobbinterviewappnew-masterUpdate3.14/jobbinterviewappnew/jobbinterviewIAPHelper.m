//
//  jobbinterviewIAPHelper.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/30/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "jobbinterviewIAPHelper.h"


@implementation jobbinterviewIAPHelper

+ (jobbinterviewIAPHelper *)sharedInstance {
    static dispatch_once_t once;
    static jobbinterviewIAPHelper * sharedInstance;
    dispatch_once(&once, ^{
        NSSet * productIdentifiers = [NSSet setWithObjects:
                                      @"videopackage1",
                                      @"videopackage3",
                                      @"videopackage4",
                                      @"videopackage5",
                                      nil];
        sharedInstance = [[self alloc] initWithProductIdentifiers:productIdentifiers];
    });
    return sharedInstance;
}

@end
