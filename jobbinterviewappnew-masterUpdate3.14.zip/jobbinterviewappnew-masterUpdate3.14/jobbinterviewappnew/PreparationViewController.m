//
//  PreparationViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/27/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "PreparationViewController.h"

@interface PreparationViewController ()

@end

@implementation PreparationViewController
@synthesize videoName,MoviePath,MovieURL,Bundle, theMovie, addView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void) bannerViewDidLoadAd:(ADBannerView *)banner
{
    [addView setHidden: NO];
    NSLog(@"Showing ad");
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [addView setHidden: YES];
    NSLog(@"Not Showing ad");
}


- (void)viewDidLoad
{
    self.title = @"Preparation";
    [super viewDidLoad];
    
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"PreparationViewController" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"PreparationViewController5" owner:self options:nil];
        }
    }
    addView.delegate = self;
    [addView setHidden: YES];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionInterview:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"1P";
   // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);

	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}

- (IBAction)actionLearn:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"2P";
    // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);
    
	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}

- (IBAction)actionHowToDress:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"3P";
    // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);
    
	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}

- (IBAction)actionLocation:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"4P";
    // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);
    
	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}

- (IBAction)actionTime:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"5P";
    // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);
    
	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}

- (IBAction)actionReview:(id)sender {
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    //NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
    //NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=@"6P";
    // NSLog(@" videoName: %@",vdName);
    NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
    self.MoviePath=moviepath;
    NSLog(@" movie Path: %@",moviepath);
    
	NSURL * url=[NSURL fileURLWithPath:MoviePath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}

}
@end
