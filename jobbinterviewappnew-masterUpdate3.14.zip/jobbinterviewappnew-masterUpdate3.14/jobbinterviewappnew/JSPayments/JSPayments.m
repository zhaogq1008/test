//
//  JSPayments.m
//  test_inAppPurchases
//
//  Created by Junaid Muhammad on 1/15/13.
//  Copyright (c) 2013 Junaid Muhammad. All rights reserved.
//

#import "JSPayments.h"

@implementation JSPayments
@synthesize delegate,vidPack;

static JSPayments * sharedPayments=nil;

+(JSPayments *)sharedPayments{
    
    if(sharedPayments == nil){
        sharedPayments = [[super allocWithZone:nil]init];
    }
    return sharedPayments;
}

// can you open itunesConnect for me


- (void)requestProducts { 
    
    self.request = [[SKProductsRequest alloc] initWithProductIdentifiers:
                    [[NSSet alloc]initWithObjects:
                     @"videopackage1",
                     @"videopackage3",
                     @"videopackage4",
                     @"videopackage5",
                      nil]];
    
    _request.delegate = self;
    
    [_request start];
    
}


- (void)restoreProducts{
    
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];

}


- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    
    NSLog(@"Received products results...");
    self.products = response.products;
    for (SKProduct *p in _products) {
        NSLog(@"%@", p.productIdentifier);
    }
    self.request = nil;
    
    NSLog(@"%@", self.products);
    
    [delegate performSelector:@selector(allProductsReceived:) withObject:_products];
}


#pragma mark - Payment states

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    
    NSLog(@"completeTransaction...");
    
    [delegate performSelector:@selector(paymentCompleted:) withObject:transaction.payment.productIdentifier];
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction paymentQueue:(SKPaymentQueue *)queue {
    
    NSLog(@"restoreTransaction...");
    
    [delegate performSelector:@selector(paymentCompleted:) withObject:transaction.payment.productIdentifier];
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    
    if (transaction.error.code != SKErrorPaymentCancelled)
        NSLog(@"Transaction error: %@", transaction.error.localizedDescription);
    else
        NSLog(@"cancelTransaction...");
    
    [delegate performSelector:@selector(paymentCompleted:) withObject:nil];
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
}


#pragma mark - Payment updatedTransactions


- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction paymentQueue:queue];
                break;
            default:
                break;
        }
    }
}

- (void)buyProductIdentifier:(SKProduct *)_productObject {
    
    NSLog(@"Buying %@...", _productObject);
    
    SKPayment *payment = [SKPayment paymentWithProduct:_productObject];
    
    [[SKPaymentQueue defaultQueue] addPayment:payment];
    
}

@end
