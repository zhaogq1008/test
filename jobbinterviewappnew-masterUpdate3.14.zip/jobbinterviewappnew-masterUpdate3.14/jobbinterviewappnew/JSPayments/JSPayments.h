//
//  JSPayments.h
//  test_inAppPurchases
//
//  Created by Junaid Muhammad on 1/15/13.
//  Copyright (c) 2013 Junaid Muhammad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

@protocol JSPaymentsDelegate <NSObject>

@optional

-(void) allProductsReceived:(NSArray *)products;
-(void) paymentCompleted:(NSString *)productName;

@end


@interface JSPayments : NSObject<SKProductsRequestDelegate, SKPaymentTransactionObserver>
{
    id<JSPaymentsDelegate>delegate;
}



@property (nonatomic, retain) id<JSPaymentsDelegate>delegate;

@property (retain, nonatomic) NSString *vidPack;
@property (retain, nonatomic) NSString *productName;
@property (nonatomic, retain) SKProductsRequest * request;
@property (nonatomic, retain) NSArray * products;



+(JSPayments *) sharedPayments;

- (void)requestProducts;
- (void)restoreProducts;
- (void)buyProductIdentifier:(SKProduct *)_productObject;

@end
