//
//  VideoViewViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <iAd/iAd.h>

@interface VideoViewViewController : UIViewController <ADBannerViewDelegate>
{
    
    MPMoviePlayerViewController * theMovie;
	UIView * view1;
	int selectedIndex;
	NSMutableArray * mVideos;
    NSMutableArray * qVideos;
    NSMutableArray * aVideos;
    NSMutableArray * myVideos;
	NSString * videoName;
	NSString * urlStr;
	UILabel * prepLabel;
    IBOutlet UISegmentedControl *segmentedControl;
    ADBannerView *addView;
  
        
}

@property (nonatomic, retain) IBOutlet ADBannerView *addView;
- (IBAction)playNextButtonAction;
- (IBAction)playPreviousButtonAction;
- (IBAction)go:(id)sender;
- (IBAction)recordAndPlay:(id)sender;
- (IBAction)segmentedControl:(id)sender;
- (IBAction)playMyVideo:(id)sender;

-(BOOL)startCameraControllerFromViewController:(UIViewController*)controller
                                 usingDelegate:(id )delegate;
-(void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void*)contextInfo;

@property(nonatomic,retain)NSString * videoName;
@property(nonatomic,retain)NSString * MoviePath;
@property(nonatomic,retain)NSBundle * Bundle;
@property(nonatomic,retain)NSURL * MovieURL;
@property(nonatomic,retain)MPMoviePlayerViewController * theMovie;
@property(nonatomic,assign)int selectedIndex;
@property(nonatomic,retain)NSMutableArray * mVideos;
@property(nonatomic,retain)NSMutableArray * qVideos;
@property(nonatomic,retain)NSMutableArray * aVideos;
@property(nonatomic,retain)NSMutableArray * myVideos;
@property(nonatomic,retain)IBOutlet UILabel * prepLabel;

@end
