//
//  QuizViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>

@interface QuizViewController : UIViewController < UITableViewDelegate, UITableViewDataSource, ADBannerViewDelegate>
{
    ADBannerView *addView;
    int                     currentSelectedQuestion;
    NSDictionary            *quizData;
    NSMutableArray          *answerList;
    IBOutlet UIView         *viewQuestion;
    IBOutlet UIView         *viewResult;

    IBOutlet UILabel        *lblQuestionN;
    IBOutlet UIButton       *btnPrev;
    IBOutlet UIButton       *btnNext;

    IBOutlet UILabel        *lblRight;
    IBOutlet UILabel        *lblWrong;
    IBOutlet UITableView    *tblResult;
}

@property (nonatomic, retain) IBOutlet ADBannerView *addView;
-(IBAction) actionPrev:(id)sender;
-(IBAction) actionNext:(id)sender;
-(IBAction) actionChecked:(id)sender;
- (IBAction)actionOk:(id)sender;

@end
