//
//  FlipCardsViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FlipCardsDetailViewController.h"
#import <iAd/iAd.h>

@interface FlipCardsViewController : UIViewController <ADBannerViewDelegate>
{
    ADBannerView *addView;
}
@property (nonatomic, retain) IBOutlet ADBannerView *addView;
- (IBAction)buttonGeneral:(id)sender;
- (IBAction)buttonAccounting:(id)sender;
- (IBAction)buttonFinance:(id)sender;
- (IBAction)buttonSales:(id)sender;
- (IBAction)buttonEngineering:(id)sender;
- (IBAction)buttonDifficult:(id)sender;
@end
