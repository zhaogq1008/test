//
//  FlipCardsDetailViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "FlipCardsDetailViewController.h"

@interface FlipCardsDetailViewController ()

@end

@implementation FlipCardsDetailViewController


@synthesize refData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        numsOfFreeCards = 10;
    }
    return self;
}
-(void) dealloc
{

    self.refData = nil;
}
-(void) getAnswer
{
    NSString *filename = [NSString stringWithFormat:@"answer_%@", self.refData];
    NSString *path =  [[NSBundle mainBundle] pathForResource:filename ofType:@"txt"];
    NSLog(@"%@" , path);
    NSString *fileContents  = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"contents is %@" , fileContents);
    NSArray *arr = [fileContents componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    arrAnswer = [[NSMutableArray alloc] init];
    
    for (int i =0; i<[ arr count]; i++)
    {
        NSString *strF = (NSString*)[arr objectAtIndex:i];
        if ([strF isEqualToString:@""] == FALSE )
        {
            [arrAnswer addObject:strF];
            //NSLog(@"added:%@" , strF);
        }
    }
//    numsOfQuestion = [arrQuestion count];
    
}
-(void) getQuestion
{
    NSString *filename = [NSString stringWithFormat:@"question_%@.txt", self.refData];
    NSString *path =  [[NSBundle mainBundle] pathForResource:filename ofType:@""];
    NSLog(@"%@" , path);
    NSString *fileContents  = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
//    NSLog(@"contents is %@" , fileContents);
    NSArray *arr = [fileContents componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    arrQuestion = [[NSMutableArray alloc] init];
    
    for (int i =0; i<[ arr count]; i++)
    {
        NSString *strF = (NSString*)[arr objectAtIndex:i];
        if ([strF isEqualToString:@""] == FALSE )
        {
            [arrQuestion addObject:strF];
            //NSLog(@"added:%@" , strF);
        }
    }
    numsOfQuestion = [arrQuestion count];
}

-(void) showFlipcards
{
    // first get datas
    [self getAnswer];
    [self getQuestion];
    // add Flipcards
    int nFlipCardNum = numsOfQuestion;
    scrollSize = scrollFlipCard.bounds.size;
    float xOffSet = 0;
    float yOffSet = 50;
    
    if ( [arrAnswer count] != numsOfQuestion )
    {
        NSLog(@"Error Not Equal Nums!!");
        NSLog(@"%d", numsOfQuestion);
        NSLog(@"%d", [arrAnswer count]);
                return;
    }
    
    [lblPage setText:[NSString stringWithFormat:@"%d/%d", 1, numsOfQuestion]];
    for ( int i = 0; i< nFlipCardNum; i++)
    {
        
        //CGRect FlipFrame = CGRectMake( xOffSet + scrollSize.width*i, yOffSet, scrollSize.width - xOffSet*2, scrollSize.height - yOffSet*2);
        
        CGRect FlipFrame;
        
        if ([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
        {
            FlipFrame = CGRectMake( xOffSet + scrollSize.width*i, yOffSet, 730, 300);
        }
        else
        {
            FlipFrame = CGRectMake( xOffSet + scrollSize.width*i, yOffSet, 320, 320);
            
        }
        
        
        
        FlipCardView *view = [[FlipCardView alloc] initWithFrame:FlipFrame Question:[arrQuestion objectAtIndex:i] Answer:[arrAnswer objectAtIndex:i]];
        [scrollFlipCard addSubview:view];
    }
    int nTemp = nFlipCardNum;
    [scrollFlipCard setContentSize:CGSizeMake(scrollSize.width*nTemp, scrollSize.height-20)];
    
}

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    [self performSelector:@selector(showFlipcards) withObject:nil afterDelay:0.05];
    self.title = @"Flipcards";
}
-(void) viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



-(void) actionNext
{
    CGFloat pageWidth = scrollFlipCard.frame.size.width;
    int currentPage = floor( (scrollFlipCard.contentOffset.x - pageWidth/2) /pageWidth) +  1;
    CGPoint pt = scrollFlipCard.contentOffset;
    pt.x = scrollSize.width * (currentPage +1);
    [scrollFlipCard scrollRectToVisible:CGRectMake( pt.x, pt.y, scrollSize.width, scrollSize.height) animated:TRUE];
}
-(void) actionFirst
{
    CGPoint pt = scrollFlipCard.contentOffset;
    pt.x = 0;
    [scrollFlipCard scrollRectToVisible:CGRectMake( pt.x, pt.y, scrollSize.width, scrollSize.height) animated:TRUE];
}

-(void) actionPrev
{
    CGFloat pageWidth = scrollFlipCard.frame.size.width;
    int currentPage = floor( (scrollFlipCard.contentOffset.x - pageWidth/2) /pageWidth) + 1;
    CGPoint pt = scrollFlipCard.contentOffset;
    pt.x = scrollSize.width * (currentPage -1);
    [scrollFlipCard scrollRectToVisible:CGRectMake( pt.x, pt.y, scrollSize.width, scrollSize.height) animated:TRUE];
}

-(void) actionLast
{
    CGPoint pt = scrollFlipCard.contentOffset;
    pt.x = scrollFlipCard.contentSize.width - scrollSize.width;
    [scrollFlipCard scrollRectToVisible:CGRectMake( pt.x, pt.y, scrollSize.width, scrollSize.height) animated:TRUE];
}

-(void) resetLable
{
    CGFloat pageWidth = scrollFlipCard.frame.size.width;
    int currentPage = floor( (scrollFlipCard.contentOffset.x - pageWidth/2) /pageWidth) +  2;
  //  NSString *strTemp = lblPage.text;
    lblPage.text = [NSString stringWithFormat:@"%d/%d", currentPage, numsOfQuestion];
    
}
-(void) scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self resetLable];
    
}
-(void)scrollViewDidScrollToTop:(UIScrollView *)scrollView
{
    [self resetLable];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self resetLable];
}

#pragma mark - in app delegate



@end
