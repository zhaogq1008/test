//
//  CheckListViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "CheckListViewController.h"
#import "CheckListAnswer.h"

@interface CheckListViewController ()

@end

@implementation CheckListViewController
@synthesize addView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Checklists", @"Checklist");
        self.tabBarItem.image = [UIImage imageNamed:@"Chechlists-Icon.png"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"Checklists";
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"CheckListViewController_iPhone" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"CheckListViewController_iPhone5" owner:self options:nil];
        }
    }
    addView.delegate = self;
    [addView setHidden: YES];
    
    
}
- (void) bannerViewDidLoadAd:(ADBannerView *)banner
{
    [addView setHidden: NO];
    NSLog(@"Showing ad");
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [addView setHidden: YES];
    NSLog(@"Not Showing ad");
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma  actions
-(void) actionAboutCompany:(id)sender
{
    
    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"About the company";
     NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
    [self.navigationController pushViewController:answerViewController animated:TRUE];
}

-(void) actionAboutJob:(id)sender
{
    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"About the Job";
    NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
    [self.navigationController pushViewController:answerViewController animated:TRUE];
}
-(void) actionKnowMyself:(id)sender
{
    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"Know yourself";
    [self.navigationController pushViewController:answerViewController animated:TRUE];
     NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
}
-(void) actionPPractise:(id)sender
{
    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"Practice";
     NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
    [self.navigationController pushViewController:answerViewController animated:TRUE];
}

-(void) actionInterview:(id)sender
{

    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"Interview";
     NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
    [self.navigationController pushViewController:answerViewController animated:TRUE];
}
-(void) actionAtInterview:(id)sender
{
    
    NSString *nibName = @"CheckListAnswer";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    CheckListAnswer *answerViewController = [[CheckListAnswer alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    answerViewController.strTbleSetter = @"At Interview";
     NSLog(@" tablesetter: %@",answerViewController.strTbleSetter);
    [self.navigationController pushViewController:answerViewController animated:TRUE];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
