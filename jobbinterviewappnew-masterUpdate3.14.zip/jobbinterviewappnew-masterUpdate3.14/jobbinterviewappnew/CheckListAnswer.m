//
//  CheckListAnswer.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//
#import "CheckListAnswer.h"

@interface CheckListAnswer ()

@end

@implementation CheckListAnswer
@synthesize strTbleSetter;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        NSArray *arrCompany = [NSArray arrayWithObjects:@"Have you checked the company's website?",
                               @"Have you googled the company?",
                               @"Do you know the company mission and philosopy?",
                               @"Do you know which players are in the market?",
                               @"Do you know the company's history?",
                               @"Do you know who is the owner of the company?",
                               @"Do you know who is the management team?",
                               @"Do you know their main products?",
                               @"Do you know any recent newstories about the company?",
                               @"Do you know the financials of the company?",
                               nil];
        //10
        NSArray *arrJob = [NSArray arrayWithObjects:@"Have you read the job description in detail?",
                           @"Do you know which skills is required for job?",
                           @"Do you know which experience is needed",
                           @"Do you know which qualities they are looking for?",
                           @"Do you know the salary range of the job?", nil];
        //15
        NSArray *arrKnowYourself = [NSArray arrayWithObjects:@"Can you explain your strengths?",
                                    @"Can you explain your weaknesses?",
                                    @"Can you explain your career goals",
                                    @"Can you explain why you want to change jobs?", nil];
        //19
        NSArray *arrPractice = [NSArray arrayWithObjects:@"Have you reviewed the preparation videos?",
                                @"Have you answered all the questions in Job Interview Videos",
                                @"Have you trained with the flip cards",
                                @"Have you practiced you five minute personal story?",
                                @"Have you practiced explaining your resume?", nil];
        //24
        NSArray *arrInterview = [NSArray arrayWithObjects:@"Do you have the time and place of the interview",
                                 @"Do you have the name of the person you will meet?",
                                 @"Do you have directions to their office?",
                                 @"Do you now where to park?",
                                 @"Have you estimated the time it takes to get there?",
                                 @"Do you have extra resumes?",
                                 @"Do you have your business cards?",
                                 @"Do you have pen and paper for taking notes?",
                                 @"Do you have appropriate clothes for interview?",
                                 @"Do you have list of references?",
                                 @"Do you have at least three relevant questions to the interviewer?", nil];
        //35
        NSArray *arrAtInterview = [NSArray arrayWithObjects:@"Arrive 10 minute early",
                                   @"Smile when you meet the interviewer",
                                   @"Give firm handshake.",
                                   @"Look into interviewers eyes",
                                   @"Sit up straight",
                                   @"Be enthusiastic",
                                   @"Turn off your mobile phone",
                                   @"Don't talk bad about current or previous employers",
                                   @"Don't talk about money unless interviewer brings it up.", nil];
        //44
        data = [[NSDictionary dictionaryWithObjectsAndKeys:arrCompany,@"About the company" , arrJob,@"About the Job",  arrKnowYourself,@"Know yourself",  arrPractice,@"Practice", arrInterview,@"Interview", arrAtInterview, @"At Interview", nil] retain];
        
    }
    return self;
}


-(void)viewWillDisappear:(BOOL)animated
{
    [[NSUserDefaults standardUserDefaults] setObject:arrayCheckDataTemp forKey:self.strTbleSetter];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *backgroundView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BG-iPhone.png"]] autorelease];
    backgroundView.frame = self.view.bounds;
    [[self view] addSubview:backgroundView];
    
    NSArray *arrDataTemp = [data objectForKey:strTbleSetter];
    
    arrayCheckDataTemp=[[NSMutableArray alloc] initWithArray:(NSArray*) [[NSUserDefaults standardUserDefaults] objectForKey:self.strTbleSetter]];
    
    if (arrayCheckDataTemp.count < 1)
    {
    //    NSMutableArray *arrSaveValue = [[NSMutableArray alloc] init];
        NSMutableArray *arrSaveValue =[NSMutableArray array];
        
        for (int k = 0; k < arrDataTemp.count; k++)
        {
            [arrSaveValue addObject:@"no"];
        }
        
        [[NSUserDefaults standardUserDefaults] setObject:arrSaveValue forKey:self.strTbleSetter];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        arrayCheckDataTemp=[[NSMutableArray alloc] initWithArray:(NSArray*) [[NSUserDefaults standardUserDefaults] objectForKey:self.strTbleSetter]];
    }
    
    arrayTableData = [[NSMutableArray alloc] initWithArray:arrDataTemp];

    self.title = @"Checklists";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayTableData count];
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1)];
    v.backgroundColor = [UIColor clearColor];
    [tableView setTableFooterView:v];
    return [v autorelease];
}

- (void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.backgroundView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Celija1.png"]] autorelease];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
       static NSString *CellIdentifier = @"CellRRR";
         UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
        // check meata data
        
        NSString *isMarked =  [arrayCheckDataTemp objectAtIndex:indexPath.row];
        if ([isMarked isEqualToString:@"yes"])
        {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        else
        {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        
        cell.textLabel.text = [arrayTableData objectAtIndex:indexPath.row];
        [cell.textLabel setNumberOfLines:0];
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone  )
        {
            [cell.textLabel setFont: [UIFont systemFontOfSize:12]];
        }
        else
        {
            [cell.textLabel setFont: [UIFont systemFontOfSize:18]];
        }
        return cell;
   
    }
    else
    {
        static NSString *CellIdentifier = @"CellRRR_iPad";
         UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        }
        // check meata data
        
        NSString *isMarked =  [arrayCheckDataTemp objectAtIndex:indexPath.row];
        if ([isMarked isEqualToString:@"yes"])
        {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        else
        {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        
        cell.textLabel.text = [arrayTableData objectAtIndex:indexPath.row];
        [cell.textLabel setNumberOfLines:0];
        if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone  )
            [cell.textLabel setFont: [UIFont systemFontOfSize:12]];
        else
        {
            [cell.textLabel setFont: [UIFont systemFontOfSize:18]];
        }
        return cell ;
    }
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark)
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
        [arrayCheckDataTemp replaceObjectAtIndex:indexPath.row withObject:@"no"];
    }
    else
    {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [arrayCheckDataTemp replaceObjectAtIndex:indexPath.row withObject:@"yes"];
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
