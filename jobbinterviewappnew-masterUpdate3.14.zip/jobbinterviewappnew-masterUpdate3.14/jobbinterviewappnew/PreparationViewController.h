//
//  PreparationViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/27/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <iAd/iAd.h>

@interface PreparationViewController : UIViewController <ADBannerViewDelegate>
{
    MPMoviePlayerViewController * theMovie;
    ADBannerView *addView;
}

@property(nonatomic, retain) IBOutlet ADBannerView *addView;
@property(nonatomic,retain)NSString * videoName;
@property(nonatomic,retain)NSString * MoviePath;
@property(nonatomic,retain)NSBundle * Bundle;
@property(nonatomic,retain)NSURL * MovieURL;
@property(nonatomic,retain)MPMoviePlayerViewController * theMovie;

- (IBAction)actionInterview:(id)sender;
- (IBAction)actionLearn:(id)sender;
- (IBAction)actionHowToDress:(id)sender;
- (IBAction)actionLocation:(id)sender;
- (IBAction)actionTime:(id)sender;
- (IBAction)actionReview:(id)sender;

@end
