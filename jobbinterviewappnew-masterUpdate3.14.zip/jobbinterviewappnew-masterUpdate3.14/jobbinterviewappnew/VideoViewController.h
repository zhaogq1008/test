//
//  VideoViewController.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <iAd/iAd.h>

@interface VideoViewController : UIViewController <ADBannerViewDelegate>
{
    ADBannerView *addView;
}

@property (nonatomic, retain) IBOutlet ADBannerView *addView;
@property (nonatomic, retain) NSString * buyProduct;

- (IBAction)prepVideos:(id)sender;

- (IBAction)video15:(id)sender;
- (IBAction)video6to10:(id)sender;
- (IBAction)video16to25:(id)sender;
- (IBAction)video26to35:(id)sender;
- (IBAction)video36to45:(id)sender;
@end
