//
//  SecondViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoViewViewController.h"
#import "PreparationViewController.h"
#import "SVProgressHUD.h"
#import "JSPayments.h"

@interface VideoViewController ()<JSPaymentsDelegate>

@end

@implementation VideoViewController
@synthesize addView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Video", @"Video");
        self.tabBarItem.image = [UIImage imageNamed:@"Video-Icon.png"];
    }
    return self;
}

- (void) bannerViewDidLoadAd:(ADBannerView *)banner
{
    [addView setHidden: NO];
    NSLog(@"Showing ad");
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [addView setHidden: YES];
    NSLog(@"Not Showing ad");
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewController_iPhone" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewController_iPhone5" owner:self options:nil];
        }
    }
    else
    {
        [[NSBundle mainBundle] loadNibNamed:@"VideoViewController_iPad" owner:self options:nil];
    }

    addView.delegate = self;
    [addView setHidden: YES];
    
    
    [[JSPayments sharedPayments] setDelegate:self];
    self.buyProduct = [NSString stringWithFormat:@""];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)prepVideos:(id)sender {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
        PreparationViewController *preparationView = [[PreparationViewController alloc] initWithNibName:@"PreparationViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:preparationView animated:YES];

    }
    else if(UI_USER_INTERFACE_IDIOM() ==UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            PreparationViewController *preparationView = [[PreparationViewController alloc] initWithNibName:@"PreparationViewController" bundle:nil];
            [self.navigationController pushViewController:preparationView animated:YES];
        }
        if(result.height == 568)
        {
            PreparationViewController *preparationView = [[PreparationViewController alloc] initWithNibName:@"PreparationViewController5" bundle:nil];
            [self.navigationController pushViewController:preparationView animated:YES];
        }
       
    }
}

- (IBAction)video15:(id)sender {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [[JSPayments sharedPayments] setVidPack:@"Video1-5"];
        VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:videoViewView animated:YES];
        
    }
    else if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        /*
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewController_iPhone" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewController_iPhone5" owner:self options:nil];
        }
         */
        CGSize result =[[UIScreen mainScreen] bounds].size;
        if(result.height ==480)
        {
        [[JSPayments sharedPayments] setVidPack:@"Video1-5"];
        VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController" bundle:nil];
        [self.navigationController pushViewController:videoViewView animated:YES];
        }
        else if(result.height ==568)
        {
            [[JSPayments sharedPayments] setVidPack:@"Video1-5"];
            VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController5" bundle:nil];
            [self.navigationController pushViewController:videoViewView animated:YES];
        }
    }
    
}

- (IBAction)video6to10:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"videopackage1"] == nil)
    {
        [self requestProductWithProductName:@"videopackage1"];
    }
    else
    {
        [[JSPayments sharedPayments] setVidPack:@"Video6-15"];
        [self loadPurchasedVideos];
    }
}

- (IBAction)video16to25:(id)sender {

    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"videopackage3"] == nil)
    {
        [self requestProductWithProductName:@"videopackage3"];
    }
    else
    {
        [[JSPayments sharedPayments] setVidPack:@"Video16-25"];
        [self loadPurchasedVideos];
    }
    
}

- (IBAction)video26to35:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"videopackage4"] == nil)
    {
        [self requestProductWithProductName:@"videopackage4"];
    }
    else
    {
        [[JSPayments sharedPayments] setVidPack:@"Video26-35"];
        [self loadPurchasedVideos];
    }
    
}

- (IBAction)video36to45:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"videopackage5"] == nil)
    {
        [self requestProductWithProductName:@"videopackage5"];
    }
    else
    {
        [[JSPayments sharedPayments] setVidPack:@"Video36-47"];
        [self loadPurchasedVideos];
    }

}

-(void) loadPurchasedVideos{

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:videoViewView animated:YES];
        
    }
    if(UI_USER_INTERFACE_IDIOM() ==UIUserInterfaceIdiomPhone)
    {
    CGSize result =[[UIScreen mainScreen] bounds].size;
    if(result.height ==480)
    {
        [[JSPayments sharedPayments] setVidPack:@"Video1-5"];
        VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController" bundle:nil];
        [self.navigationController pushViewController:videoViewView animated:YES];
    }
    else if(result.height ==568)
        {
        [[JSPayments sharedPayments] setVidPack:@"Video1-5"];
        VideoViewViewController *videoViewView = [[VideoViewViewController alloc] initWithNibName:@"VideoViewViewController5" bundle:nil];
        [self.navigationController pushViewController:videoViewView animated:YES];
        }
    }
}



- (void) showMessageString:(NSString *)message{
   
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"Message alert!" message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    [alert show];
    
    [SVProgressHUD dismiss];
}


#pragma mark - JSPayments


-(void) requestProductWithProductName:(NSString *) pName{

    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    
    [[JSPayments sharedPayments] requestProducts];
    
    [self setBuyProduct:pName];
    
}
-(void) allProductsReceived:(NSArray *)products{
    
    if (products.count <= 0){
        
        [SVProgressHUD dismiss];
        [self showMessageString:@"Error in loading the Product list"];
        return;
    }
    
    for (SKProduct *p in products) {
        
        if ([p.productIdentifier isEqualToString:self.buyProduct])
        {
            [[JSPayments sharedPayments] buyProductIdentifier:p];
        }
    }
}


-(void)paymentCompleted:(NSString *)productName{
    
    [SVProgressHUD dismiss];

    if ([productName isEqualToString:@"videopackage1"])
    {
        NSLog(@"purchased videopackage1");
        
        [[JSPayments sharedPayments] setVidPack:@"Video6-15"];
        [[NSUserDefaults standardUserDefaults] setObject:@"Purchased" forKey:@"videopackage1"];
    }
    
    else if ([productName isEqualToString:@"videopackage3"])
    {
        NSLog(@"purchased videopackage3");
        
        [[JSPayments sharedPayments] setVidPack:@"Video16-25"];
        [[NSUserDefaults standardUserDefaults] setObject:@"Purchased" forKey:@"videopackage3"];
    }
    
    else if ([productName isEqualToString:@"videopackage4"])
    {
        NSLog(@"purchased videopackage4");
        
        [[JSPayments sharedPayments] setVidPack:@"Video26-35"];
        [[NSUserDefaults standardUserDefaults] setObject:@"Purchased" forKey:@"videopackage4"];
    }
    
    else if ([productName isEqualToString:@"videopackage5"])
    {
        NSLog(@"purchased videopackage5");
        [[JSPayments sharedPayments] setVidPack:@"Video36-47"];
        [[NSUserDefaults standardUserDefaults] setObject:@"Purchased" forKey:@"videopackage5"];
    }
    
    if (productName) {
        [self loadPurchasedVideos];
    }
    

    
}

@end
