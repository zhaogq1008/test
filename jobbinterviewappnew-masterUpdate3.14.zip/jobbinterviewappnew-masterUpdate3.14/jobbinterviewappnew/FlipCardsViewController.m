//
//  SecondViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/22/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "FlipCardsViewController.h"

@interface FlipCardsViewController ()

@end

@implementation FlipCardsViewController
@synthesize addView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Flipcards", @"Flipcards");
        self.tabBarItem.image = [UIImage imageNamed:@"Flipcards.png"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"FlipCardsViewController_iPhone" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"FlipCardsViewController_iPhone5" owner:self options:nil];
        }
    }
    addView.delegate = self;
    [addView setHidden: YES];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void) bannerViewDidLoadAd:(ADBannerView *)banner
{
    [addView setHidden: NO];
    NSLog(@"Showing ad");
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [addView setHidden: YES];
    NSLog(@"Not Showing ad");
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonGeneral:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
        NSLog(@"NIB %@",nibName);
        
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"general";
    [self.navigationController pushViewController:controller animated:TRUE];
}

- (IBAction)buttonAccounting:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"accounting";
    [self.navigationController pushViewController:controller animated:TRUE];

}

- (IBAction)buttonFinance:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"finance";
    [self.navigationController pushViewController:controller animated:TRUE];

}

- (IBAction)buttonSales:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"sales";
    [self.navigationController pushViewController:controller animated:TRUE];

}

- (IBAction)buttonEngineering:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"engineering";
    [self.navigationController pushViewController:controller animated:TRUE];

}

- (IBAction)buttonDifficult:(id)sender {
    NSString *nibName = @"FlipCardsDetailViewController";
    if ( [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone )
    {
        nibName = [NSString stringWithFormat:@"%@_iPhone" , nibName];
    }else{
        nibName = [NSString stringWithFormat:@"%@_iPad" , nibName];
    }
    FlipCardsDetailViewController *controller = [[FlipCardsDetailViewController alloc] initWithNibName:nibName bundle:[NSBundle mainBundle]];
    controller.refData = @"difficult";
    [self.navigationController pushViewController:controller animated:TRUE];

}
@end
