//
//  VideoViewViewController.m
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//

#import "VideoViewViewController.h"
#import "IAPHelper.h"
#import "jobbinterviewIAPHelper.h"
#import "JSPayments.h"
#import <StoreKit/StoreKit.h>

@interface VideoViewViewController ()

@end

@implementation VideoViewViewController

@synthesize theMovie;
@synthesize selectedIndex;
@synthesize mVideos, qVideos, aVideos, myVideos;
@synthesize videoName,MoviePath,MovieURL,Bundle;
@synthesize prepLabel, addView;

int variablaSegment;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void) viewDidAppear:(BOOL)animated{
    
}

- (void) updateTitle; {
    NSString *vidPack = [JSPayments sharedPayments].vidPack;
    NSLog(@"vidpack = %@", vidPack);
    int vidAddition = 0;

    if ([vidPack isEqualToString:@"Video1-5"])
    {
        vidAddition = 0;
        NSLog(@"vidaddition = %d", vidAddition);
    }
    
    else if ([vidPack isEqualToString:@"Video6-15"])
    {
        vidAddition = 5;
        NSLog(@"vidaddition = %d", vidAddition);
    }
    else if ([vidPack isEqualToString:@"Video16-25"])
    {
        vidAddition = 15;
        NSLog(@"vidaddition = %d", vidAddition);
    }
    else if ([vidPack isEqualToString:@"Video26-35"])
    {
        vidAddition = 25;
        NSLog(@"vidaddition = %d", vidAddition);
    }
    else if ([vidPack isEqualToString:@"Video36-47"])
    {
        vidAddition = 35;
        NSLog(@"vidaddition = %d", vidAddition);
    }

    NSLog(@"updateTitle");
    NSString *name;
    if (variablaSegment == 0) {
        name = @"Question";
    }
    if (variablaSegment == 1) {
        name = @"Mentor";
    }
    if (variablaSegment == 2) {
        name = @"Answer";
    }
    int number;
    number = selectedIndex +1 + vidAddition;
    NSLog(@"updateTitle %d", number);
    
    NSString* title = [NSString stringWithFormat:@"%@ %d", name, number];
    NSLog(@"updateTitle %@", title);
    self.title = title;

}
- (void) bannerViewDidLoadAd:(ADBannerView *)banner
{
    [addView setHidden: NO];
    NSLog(@"Showing ad");
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    [addView setHidden: YES];
    NSLog(@"Not Showing ad");
}

- (void)viewDidLoad
{
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        CGSize result = [[UIScreen mainScreen] bounds].size;
        if(result.height == 480)
        {
            // iPhone Classic
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewViewController" owner:self options:nil];
        }
        if(result.height == 568)
        {
            // iPhone 5
            [[NSBundle mainBundle] loadNibNamed:@"VideoViewViewController5" owner:self options:nil];
        }
    }
    addView.delegate = self;
    [addView setHidden: YES];
    
	selectedIndex=0;
    variablaSegment = 0;
 
    [self updateTitle];
	
    urlStr = @"http://www.appsonite.com/Videos/";
	
    //Video arrays
    mVideos=[[NSMutableArray alloc]init];
    qVideos=[[NSMutableArray alloc]init];
    aVideos=[[NSMutableArray alloc]init];
    myVideos=[[NSMutableArray alloc]init];

    NSString *vidPack = [JSPayments sharedPayments].vidPack;
    
    [myVideos addObject:@"myVideo1"];
	[myVideos addObject:@"myVideo2"];
	[myVideos addObject:@"myVideo3"];
	[myVideos addObject:@"myVideo4"];
	[myVideos addObject:@"myVideo5"];
    
    if ([vidPack isEqualToString:@"Video1-5"]) {
        
        [mVideos addObject:@"1M"];
        [mVideos addObject:@"2M"];
        [mVideos addObject:@"3M"];
        [mVideos addObject:@"4M"];
        [mVideos addObject:@"5M"];
        
        [qVideos addObject:@"1Q"];
        [qVideos addObject:@"2Q"];
        [qVideos addObject:@"3Q"];
        [qVideos addObject:@"4Q"];
        [qVideos addObject:@"5Q"];
        
        [aVideos addObject:@"1A"];
        [aVideos addObject:@"2A"];
        [aVideos addObject:@"3A"];
        [aVideos addObject:@"4A"];
        [aVideos addObject:@"5A"];
        
    }
    else if ([vidPack isEqualToString:@"Video6-15"]) {
        NSLog(@"enter vidpack Video6-15");
        for (int i = 6; i<=15; i++) {
            
            urlStr = @"http://www.appsonite.com/Videos/Group_2/";
            
            [mVideos addObject:[NSString stringWithFormat:@"%dM",i]];
            [qVideos addObject:[NSString stringWithFormat:@"%dQ",i]];
            [aVideos addObject:[NSString stringWithFormat:@"%dA",i]];
            NSLog(@"add video %d", i);
        }
    
    }
    else if ([vidPack isEqualToString:@"Video16-25"]) {
      
        for (int i = 16; i<=25; i++) {
            
            urlStr = @"http://www.appsonite.com/Videos/Group_3/";
            
            [mVideos addObject:[NSString stringWithFormat:@"%dM",i]];
            [qVideos addObject:[NSString stringWithFormat:@"%dQ",i]];
            [aVideos addObject:[NSString stringWithFormat:@"%dA",i]];
            
        }
 
    }
    else if ([vidPack isEqualToString:@"Video26-35"]) {
        for (int i = 26; i<=35; i++) {
            
            urlStr = @"http://www.appsonite.com/Videos/Group_4/";
            
            [mVideos addObject:[NSString stringWithFormat:@"%dM",i]];
            [qVideos addObject:[NSString stringWithFormat:@"%dQ",i]];
            [aVideos addObject:[NSString stringWithFormat:@"%dA",i]];
            
        }
 
    }
    else if ([vidPack isEqualToString:@"Video36-47"]) {
        
        for (int i = 36; i<=47; i++) {
            
            urlStr = @"http://www.appsonite.com/Videos/Group_5/";
            
            [mVideos addObject:[NSString stringWithFormat:@"%dM",i]];
            [qVideos addObject:[NSString stringWithFormat:@"%dQ",i]];
            [aVideos addObject:[NSString stringWithFormat:@"%dA",i]];
            
        }

    }
	
//    int countArray = [qVideos count];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)go:(id)sender {
    
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init];
	videoName=[[NSString alloc]init];
	MovieURL=[[NSURL alloc]init ];
	
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    
    NSURL * url = nil;
    NSLog(@"vidpack = %@", [JSPayments sharedPayments].vidPack);
    if ([[JSPayments sharedPayments].vidPack isEqualToString:@"Video1-5"]) {
        
        if (variablaSegment == 0){
            NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
            //NSLog(@" Selected index is %d", selectedIndex);
            self.videoName=vdName;
            //NSLog(@" videoName: %@",vdName);
            NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
            self.MoviePath=moviepath;
            //NSLog(@" movie Path: %@",moviepath);
        }
        if (variablaSegment == 1){
            NSString * vdName=[NSString stringWithFormat:@"%@",[mVideos objectAtIndex:selectedIndex]];
            self.videoName=vdName;
            // NSLog(@" videoName: %@",vdName);
            NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
            self.MoviePath=moviepath;
            // NSLog(@" movie Path: %@",moviepath);
        }
        if (variablaSegment == 2){
            NSString * vdName=[NSString stringWithFormat:@"%@",[aVideos objectAtIndex:selectedIndex]];
            self.videoName=vdName;
            // NSLog(@" videoName: %@",vdName);
            NSString * moviepath=[Bundle pathForResource:videoName ofType:@"mp4"];
            self.MoviePath=moviepath;
            // NSLog(@" movie Path: %@",moviepath);
        }
        
        url=[NSURL fileURLWithPath:MoviePath];

        
    }else{
        
        NSString *urlPath = @"";
        
        if (variablaSegment == 0){
            NSString * vdName=[NSString stringWithFormat:@"%@",[qVideos objectAtIndex:selectedIndex]];
            //NSLog(@" Selected index is %d", selectedIndex);
            self.videoName=vdName;
            urlPath = [NSString stringWithFormat:@"%@%@.mp4",urlStr,[qVideos objectAtIndex:selectedIndex]];
        }
        if (variablaSegment == 1){
            NSString * vdName=[NSString stringWithFormat:@"%@",[mVideos objectAtIndex:selectedIndex]];
            self.videoName=vdName;
            urlPath = [NSString stringWithFormat:@"%@%@.mp4",urlStr,[mVideos objectAtIndex:selectedIndex]];
        }
        if (variablaSegment == 2){
            NSString * vdName=[NSString stringWithFormat:@"%@",[aVideos objectAtIndex:selectedIndex]];
            self.videoName=vdName;
            urlPath = [NSString stringWithFormat:@"%@%@.mp4",urlStr,[aVideos objectAtIndex:selectedIndex]];
        }
    
        url = [NSURL URLWithString:urlPath];
    }
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}
    
    NSLog(@"selected index is %d", selectedIndex);
}
-(IBAction)playNextButtonAction{
    
    int countArray = [qVideos count]-1;
    if (selectedIndex == countArray){
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"End of videos"
                                                          message:@"Push play or backward"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }
    else{
        selectedIndex = selectedIndex + 1;
    }
    NSLog(@" Selected index is %d", selectedIndex);
    [self updateTitle];
    
    
}
-(IBAction)playPreviousButtonAction{
    
    if (selectedIndex==0){
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"End of videos"
                                                          message:@"Push play or forward"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }
    else{
        selectedIndex = selectedIndex - 1;
    }
    NSLog(@" Selected index is %d", selectedIndex);
    [self updateTitle];
}


- (IBAction)playMyVideo:(id)sender {
    
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
    
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
	
	NSLog(@" bundle: %@",bundle);
    NSString * vdName=[NSString stringWithFormat:@"%@",[myVideos objectAtIndex:selectedIndex]];
    NSLog(@" Selected index is %d", selectedIndex);
    self.videoName=vdName;
    NSLog(@" Play videoName: %@",vdName);
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentsDirectory = [documentPaths objectAtIndex:0];
    NSLog(@"document directory%@", documentsDirectory);

   // NSString * moviepath=[documentsDirectory stringByAppendingPathComponent:myVideoName];
    self.MoviePath=[documentsDirectory stringByAppendingPathComponent:videoName];
    NSLog(@" movie Path: %@",MoviePath);
    NSString *fullPath;
    fullPath = [MoviePath stringByAppendingFormat:@".mp4"];
    
    
	NSURL * url=[NSURL fileURLWithPath:fullPath];
	NSLog(@" URL Path: %@",url);
	
	self.MovieURL=url;
	
	UIGraphicsBeginImageContext(CGSizeMake(1,1));
	MPMoviePlayerViewController * player=[[MPMoviePlayerViewController alloc]initWithContentURL:MovieURL ];
    UIGraphicsEndImageContext();
	
	if (player) {
		[self presentMoviePlayerViewControllerAnimated:player];
		
		[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieFinishedCallback:) name:MPMoviePlayerPlaybackDidFinishNotification object:player ];
	}
    
    NSLog(@"selected index is %d", selectedIndex);
}

- (IBAction)recordAndPlay:(id)sender {
    [self startCameraControllerFromViewController:self usingDelegate:self];
}

- (IBAction)segmentedControl:(id)sender {
    
    if(segmentedControl.selectedSegmentIndex == 0){
        variablaSegment = 0;
        NSLog(@" Seg pushed Var = %d", variablaSegment);
        [self updateTitle];
		
	}
	if(segmentedControl.selectedSegmentIndex == 1){
        variablaSegment = 1;
        NSLog(@" Seg pushed Var = %d", variablaSegment);
        [self updateTitle];
	}
    if(segmentedControl.selectedSegmentIndex == 2){
        variablaSegment = 2;
        NSLog(@" Seg pushed Var = %d", variablaSegment);
        [self updateTitle];
        
	}
}


-(BOOL)startCameraControllerFromViewController:(UIViewController*)controller
                                 usingDelegate:(id )delegate {
    // 1 - Validattions
    if (([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera] == NO)
        || (delegate == nil)
        || (controller == nil)) {
        return NO;
    }
    // 2 - Get image picker
    UIImagePickerController *cameraUI = [[UIImagePickerController alloc] init];
    cameraUI.sourceType = UIImagePickerControllerSourceTypeCamera;
    // Displays a control that allows the user to choose movie capture
    cameraUI.mediaTypes = [[NSArray alloc] initWithObjects:(NSString *)kUTTypeMovie, nil];
    // Hides the controls for moving & scaling pictures, or for
    // trimming movies. To instead show the controls, use YES.
    cameraUI.allowsEditing = NO;
    cameraUI.delegate = delegate;
    // 3 - Display image picker
    [controller presentModalViewController: cameraUI animated: YES];
    return YES;
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    Bundle=[NSBundle mainBundle];
	MoviePath=[[NSString alloc]init ];
	videoName=[[NSString alloc]init ];
	MovieURL=[[NSURL alloc]init ];
    
	NSBundle * bundle=[NSBundle mainBundle];
	self.Bundle=bundle;
    NSLog(@" bundle: %@",bundle);
    
    NSString *myVideoName;
    myVideoName = [NSString stringWithFormat:@"%@%d", @"myVideo", selectedIndex+1];
    int countvid = [myVideos count];
    NSLog(@"count VidArray %d", countvid);
    NSLog(@"selected index in save %d", selectedIndex);
    //[myVideos insertObject: myVideoName atIndex: selectedIndex];
    [myVideos insertObject:myVideoName atIndex: selectedIndex];
    NSLog(@"myVideoName save %@", myVideoName);
    
    self.movieURL = info[UIImagePickerControllerMediaURL];
    NSData * movieData = [NSData dataWithContentsOfURL:MovieURL];
    //NSLog(@"movie data%@", movieData);
     
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentsDirectory = [documentPaths objectAtIndex:0];
    NSLog(@"document directory%@", documentsDirectory);
    
    NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:myVideoName];
    fullPath = [fullPath stringByAppendingFormat:@".mp4"];
     NSLog(@" save full path %@", fullPath);
    [movieData writeToFile:fullPath atomically:YES];
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    //NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];
    [self dismissModalViewControllerAnimated:NO];
    // Handle a movie capture
    /*if (CFStringCompare ((__bridge_retained CFStringRef) mediaType, kUTTypeMovie, 0) == kCFCompareEqualTo) {
       
      
        NSString *moviePath = [[info objectForKey:UIImagePickerControllerMediaURL] path];
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(moviePath)) {
            UISaveVideoAtPathToSavedPhotosAlbum(moviePath, self,
                                                @selector(video:didFinishSavingWithError:contextInfo:), nil);
        }
    }*/
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

-(void)video:(NSString*)videoPath didFinishSavingWithError:(NSError*)error contextInfo:(void*)contextInfo {
    if (error) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Video Saving Failed"
                                                       delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Video Saved" message:@"Saved To Photo Album"
                                                       delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}
@end
