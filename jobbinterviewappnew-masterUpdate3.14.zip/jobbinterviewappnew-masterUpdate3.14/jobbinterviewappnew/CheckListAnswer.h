//
//  CheckListAnswer.h
//  jobbinterviewappnew
//
//  Created by Robin Grønvold on 5/23/13.
//  Copyright (c) 2013 appsonite. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface CheckListAnswer : UITableViewController <UITableViewDelegate, UITableViewDataSource>
{
    NSDictionary *data;
    NSMutableArray *arrayCheckDataTemp;
    NSMutableArray *arrayTableData;
}

@property (retain) NSString *strTbleSetter;

@end
